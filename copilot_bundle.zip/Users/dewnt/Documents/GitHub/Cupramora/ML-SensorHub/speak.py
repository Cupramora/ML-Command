# speak.py

import time
from voice import generate_voice_line  # Core brain generates how to say it

VOICE_LOG = "voice_output_log.txt"

# 🎙️ Voice routing maps
MOOD_VOICE_MAP = {
    "curious": "WhisperBot",
    "confident": "CoreVoice",
    "nostalgic": "EchoTone",
    "anxious": "Flicker",
    "neutral": "CoreVoice"
}

INTENT_VOICE_OVERRIDE = {
    "trigger_panic_mode": "SirenCore",
    "memory_recalled": "EchoTone",
    "memory_not_found": "Flicker"
}

def select_voice(intent: str, mood: str) -> str:
    # Intent overrides mood if defined
    if intent in INTENT_VOICE_OVERRIDE:
        return INTENT_VOICE_OVERRIDE[intent]
    return MOOD_VOICE_MAP.get(mood, "CoreVoice")

def say(intent: str, context: dict = {}):
    mood = context.get("mood", "neutral")
    speaker = select_voice(intent, mood)

    # Optional console mutterings
    if intent == "memory_recalled":
        print(f"...I remember something about {context.get('tag', 'something')}.")
    elif intent == "memory_not_found":
        print(f"...nothing comes to mind for {context.get('tag', 'that')}.")

    # Generate and log voice line
    line = generate_voice_line(intent, context)
    timestamp = time.strftime("[%H:%M:%S] ", time.localtime())
    full_line = timestamp + line

    with open(VOICE_LOG, "a", encoding="ascii", errors="replace") as f:
        f.write(full_line + "\n")

    # Local echo with speaker identity
    print(f"[{speaker}]", line)

    # Optional: pipe to speaker
    # speak_aloud(line, voice=speaker)
