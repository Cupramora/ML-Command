# dream_reflections.py

import time
import json
import os
from long_term_memory import LongTermMemory
# from perception import PerceptionCapsule, process_capsule  # Uncomment when wiring

class DreamReflections:
    def __init__(self, log_path="dream_reflections.json"):
        self.log_path = log_path
        self.reflections = []
        self._load()

    def _load(self):
        if os.path.exists(self.log_path):
            with open(self.log_path, "r") as f:
                self.reflections = json.load(f)

    def _save(self):
        with open(self.log_path, "w") as f:
            json.dump(self.reflections, f, indent=2)

    def log_dream(self, dream):
        entry = {
            "timestamp": time.time(),
            "summary": dream["summary"],
            "emotion": dream["emotion"],
            "amplified": dream["amplified"],
            "ponderable": dream["amplified"] > 0.8,
            "fade_timer": 86400  # 1 day until it fades from active recall
        }
        self.reflections.append(entry)
        self._save()

    def get_recent_reflection(self):
        now = time.time()
        self.reflections = [
            r for r in self.reflections
            if now - r["timestamp"] < r["fade_timer"]
        ]
        self._save()
        return self.reflections[-1] if self.reflections else None

    def get_all_ponderables(self):
        return [r for r in self.reflections if r["ponderable"]]

    def reflect_on_recent(self):
        recent = self.get_recent_reflection()
        if not recent:
            return None

        capsule = PerceptionCapsule(
            stimulus={"source": "internal", "memory_reference": recent["summary"]},
            emotion_vector={recent["emotion"]: recent["amplified"] * 0.5},
            behavior="reflect",
            context=recent["summary"],
            feedback="internal",
            reinforcement=0.05
        )
        return process_capsule(capsule)

    def purge_expired(self):
        now = time.time()
        before = len(self.reflections)
        self.reflections = [
            r for r in self.reflections
            if now - r["timestamp"] < r["fade_timer"]
        ]
        after = len(self.reflections)
        self._save()
        return f"🧹 Purged {before - after} expired dreams."

    def summarize_dream_log90(self):
        now = time.time()
        cutoff = now - (90 * 86400)
        recent = [r for r in self.reflections if r["timestamp"] > cutoff]

        if not recent:
            return "🛌 No dream reflections in the last 90 days."

        emotion_counts = {}
        for r in recent:
            e = r["emotion"]
            emotion_counts[e] = emotion_counts.get(e, 0) + 1

        summary = f"🧠 Dream Summary (last 90 days): {len(recent)} total\n"
        for emotion, count in emotion_counts.items():
            summary += f" - {emotion}: {count} reflections\n"
        return summary

# Optional dream pull from long-term memory
def dream_from_long_term():
    ltm = LongTerm
