# sense_convergence.py

import time
from vision_handler import get_visual_input
from audio_handler import get_audio_input
from touch_handler import get_touch_input
from transmitter import transmit_data  # Your existing outbound system

class UnifiedStimulus:
    def __init__(self, visual=None, audio=None, tactile=None):
        self.timestamp = time.time()
        self.visual = visual
        self.audio = audio
        self.tactile = tactile

    def to_dict(self):
        return {
            "timestamp": self.timestamp,
            "visual": self.visual,
            "audio": self.audio,
            "tactile": self.tactile
        }

def converge_and_transmit():
    visual = get_visual_input()
    audio = get_audio_input()
    tactile = get_touch_input()

    stimulus = UnifiedStimulus(
        visual=visual,
        audio=audio,
        tactile=tactile
    )

    transmit_data(stimulus.to_dict())
