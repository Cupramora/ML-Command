# png_input.py
# watches for new PNG files, processes to STL, and logs filename archive

import os
import time
from stl_pipeline import generate_stl
import shutil

WATCH_FOLDER = "png_files"
SCAN_INTERVAL = 5  # seconds

def process_png(file_path):
    print(" processing:", file_path)
    generate_stl(file_path)

def run_watcher():
    seen = set()
    os.makedirs(WATCH_FOLDER, exist_ok=True)

    print(" watching folder:", WATCH_FOLDER)
    while True:
        files = [f for f in os.listdir(WATCH_FOLDER) if f.endswith(".png")]
        for f in files:
            full_path = os.path.join(WATCH_FOLDER, f)
            if f not in seen:
                process_png(full_path)
                seen.add(f)
        time.sleep(SCAN_INTERVAL)

if __name__ == "__main__":
    run_watcher()
