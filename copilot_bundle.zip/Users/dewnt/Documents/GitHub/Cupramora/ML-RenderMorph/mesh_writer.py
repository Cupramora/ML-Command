# mesh_writer.py
# writes STL file from vertex and face data using NumPy-STL

import numpy as np
from stl import mesh
import os

def write_stl(vertices, faces, filename="output.stl", folder="output_models"):
    """
    Saves STL from given vertices and triangle faces.
    Each face must be 3 vertices in [x, y, z] format.
    """
    os.makedirs(folder, exist_ok=True)
    filepath = os.path.join(folder, filename)

    data = np.zeros(len(faces), dtype=mesh.Mesh.dtype)
    for i, triangle in enumerate(faces):
        data["vectors"][i] = np.array(triangle)

    model = mesh.Mesh(data)
    model.save(filepath)

    return filepath
