# shape_to_mesh.py
# converts a 2D contour into 3D vertex and face arrays for STL export

import numpy as np

def extrude_contour(contour, depth=2.0, scale=1.0):
    """
    Takes Nx2 contour array and returns STL-ready vertices and face list.
    Extrudes vertically from z=0 to z=depth.
    """
    if contour.ndim != 2 or contour.shape[1] != 2:
        print("invalid contour shape.")
        return None, None

    # scale and center contour
    contour = contour.astype(np.float32) * scale
    contour -= np.mean(contour, axis=0)

    # generate top and bottom vertices
    vertices_top = np.array([[x, y, depth] for x, y in contour])
    vertices_bottom = np.array([[x, y, 0.0] for x, y in contour])
    vertices = np.vstack((vertices_top, vertices_bottom))

    # generate side faces (triangulated quads)
    faces = []
    n = len(contour)
    for i in range(n):
        next_i = (i + 1) % n
        faces.append([vertices_top[i], vertices_top[next_i], vertices_bottom[i]])     # top edge
        faces.append([vertices_bottom[i], vertices_top[next_i], vertices_bottom[next_i]])  # bottom edge

    return vertices, faces
