# stl_pipeline.py
# converts PNG silhouette into STL mesh and saves into CupricCurios repo

import os
import cv2
from image_loader import load_and_binarize
from contour_mapper import get_largest_contour
from shape_to_mesh import extrude_contour
from mesh_writer import write_stl
from repo_saver import save_to_curio

def generate_stl(image_path, depth=2.0, scale=1.0):
    # STEP 1: Load and binarize image
    binary = load_and_binarize(image_path)
    if binary is None:
        print(" image load failed")
        return None

    # STEP 2: Get largest contour from silhouette
    contour = get_largest_contour(binary)
    if contour is None or contour.size == 0:
        print(" no valid contour found")
        return None

    # STEP 3: Extrude 2D contour to 3D mesh
    vertices, faces = extrude_contour(contour, depth=depth, scale=scale)
    if vertices is None or faces is None:
        print(" extrusion failed")
        return None

    # STEP 4: Write STL file from mesh
    base = os.path.splitext(os.path.basename(image_path))[0]
    filename = base + ".stl"
    stl_path = write_stl(vertices, faces, filename=filename)

    print(" STL generated:", stl_path)

    # STEP 5: Archive STL into CupricCurios
    result = save_to_curio(stl_path)
    print(" saved to CupricCurios:", result["location"])
    return result

# optional CLI interface
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python stl_pipeline.py <image_path>")
    else:
        generate_stl(sys.argv[1])