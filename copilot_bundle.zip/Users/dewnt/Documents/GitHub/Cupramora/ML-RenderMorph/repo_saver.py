# repo_saver.py
# saves STL output into CupricCurios repo for neural artifact curation

import os
import shutil

def save_to_curio(stl_path, curio_repo="~/GitHub/CupricCurios", subfolder="printed_forms"):
    # resolve full path
    curio_repo = os.path.expanduser(curio_repo)
    target_dir = os.path.join(curio_repo, subfolder)
    os.makedirs(target_dir, exist_ok=True)

    basename = os.path.basename(stl_path)
    destination = os.path.join(target_dir, basename)

    # copy STL file
    shutil.copyfile(stl_path, destination)

    # optional: log metadata (e.g. name + description) if needed later
    # with open(os.path.join(target_dir, "index.json"), "a") as log:
    #     log.write(json.dumps({"file": basename, "saved": time.time()}))

    return {
        "status": "saved",
        "filename": basename,
        "location": destination
    }