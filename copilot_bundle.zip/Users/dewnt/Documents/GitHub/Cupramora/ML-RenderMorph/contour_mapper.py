# contour_mapper.py
# extracts the outer shape contour from a binarized image

import cv2

def get_largest_contour(binary_image):
    """
    Finds the largest external contour in the binary image.
    Returns it as a simplified Nx2 array of (x, y) points.
    """
    contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    largest = max(contours, key=cv2.contourArea)
    return largest.squeeze()
