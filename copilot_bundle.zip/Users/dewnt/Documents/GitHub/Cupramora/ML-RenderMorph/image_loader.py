# image_loader.py
# loads PNG images and prepares them for contour mapping

import cv2
import numpy as np

def load_and_binarize(image_path, invert=True):
    """
    Loads a PNG image, converts to grayscale, then thresholds to binary.
    If invert=True, dark shapes on light background are inverted to white on black.
    """
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print("image failed to load:", image_path)
        return None

    if invert:
        _, binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY_INV)
    else:
        _, binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)

    return binary
