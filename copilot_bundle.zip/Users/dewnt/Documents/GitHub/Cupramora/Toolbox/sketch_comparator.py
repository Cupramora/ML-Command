# sketch_comparator.py

import cv2
import numpy as np

class SketchComparator:
    """
    Compares two sketches using structural similarity and contour overlap.
    """

    def __init__(self, path1: str, path2: str):
        self.img1 = cv2.imread(path1, cv2.IMREAD_GRAYSCALE)
        self.img2 = cv2.imread(path2, cv2.IMREAD_GRAYSCALE)

    def compare_histograms(self) -> float:
        """
        Compares image histograms (0–1 similarity).
        """
        hist1 = cv2.calcHist([self.img1], [0], None, [256], [0, 256])
        hist2 = cv2.calcHist([self.img2], [0], None, [256], [0, 256])
        return cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL)

    def compare_structural_similarity(self) -> float:
        """
        Uses SSIM to compare structural similarity (0–1).
        """
        from skimage.metrics import structural_similarity as ssim
        score, _ = ssim(self.img1, self.img2, full=True)
        return score
