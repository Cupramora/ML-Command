# capsule_terminal.py

class CapsuleTerminal:
    """
    Acts as a command-line interface or internal dispatcher for math capsules.
    Allows querying, routing, and previewing capsule content.
    """

    def __init__(self, capsule_store: list):
        self.capsules = capsule_store

    def list_capsules(self, tag_filter: str = None) -> list:
        """
        Returns a list of capsule summaries, optionally filtered by tag.
        """
        return [
            f"[{i}] {cap['source']} | tags: {cap['tags']}"
            for i, cap in enumerate(self.capsules)
            if tag_filter is None or tag_filter in cap["tags"]
        ]

    def view_capsule(self, index: int) -> dict | None:
        """
        Returns the full contents of a capsule by index.
        """
        if 0 <= index < len(self.capsules):
            return self.capsules[index]
        return None

    def dispatch_to_command(self, index: int) -> dict | None:
        """
        Sends a capsule to the command module for long-term logging.
        """
        capsule = self.view_capsule(index)
        if capsule:
            # Simulate sending to command
            print(f"Dispatching capsule {index} to command...")
            return capsule
        return None
