# circle_detector.py
# Finds circular patterns and returns radius, center, area
