# sketch_improver.py

import cv2
import numpy as np

class SketchImprover:
    """
    Enhances and cleans up whiteboard sketches.
    Supports denoising, contrast adjustment, and edge sharpening.
    """

    def __init__(self, image_path: str):
        self.image_path = image_path
        self.original = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        self.processed = self.original.copy()

    def denoise(self):
        self.processed = cv2.fastNlMeansDenoising(self.processed, h=30)
        return self.processed

    def enhance_contrast(self):
        self.processed = cv2.equalizeHist(self.processed)
        return self.processed

    def sharpen_edges(self):
        kernel = np.array([[0, -1, 0],
                           [-1, 5,-1],
                           [0, -1, 0]])
        self.processed = cv2.filter2D(self.processed, -1, kernel)
        return self.processed

    def save(self, output_path: str):
        cv2.imwrite(output_path, self.processed)
        print(f"🧽 Enhanced sketch saved to {output_path}")
