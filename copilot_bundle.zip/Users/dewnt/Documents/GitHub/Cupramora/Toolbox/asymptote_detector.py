# asymptote_detector.py

from sympy import symbols, simplify, limit, oo, sympify, denom

x = symbols('x')

def detect_vertical_asymptotes(expr_str: str) -> list:
    """
    Finds vertical asymptotes by solving where the denominator is zero.
    """
    try:
        expr = simplify(expr_str)
        d = denom(expr)
        return list(solve(d, x))
    except Exception:
        return []

def detect_horizontal_asymptote(expr_str: str) -> float | str | None:
    """
    Estimates horizontal asymptote by computing limit as x → ±∞.
    """
    try:
        expr = simplify(expr_str)
        lim_pos = limit(expr, x, oo)
        lim_neg = limit(expr, x, -oo)
        if lim_pos == lim_neg:
            return lim_pos
        return f"lim⁺ = {lim_pos}, lim⁻ = {lim_neg}"
    except Exception:
        return None

def detect_oblique_asymptote(expr_str: str) -> str | None:
    """
    Checks for slant (oblique) asymptotes by polynomial division.
    Only applies when degree(numerator) = degree(denominator) + 1
    """
    try:
        expr = simplify(expr_str)
        num, den = expr.as_numer_denom()
        if num.is_polynomial(x) and den.is_polynomial(x):
            q, r = div(num, den, domain='QQ')
            if q.as_poly().degree() == 1:
                return str(q)
        return None
    except Exception:
        return None
