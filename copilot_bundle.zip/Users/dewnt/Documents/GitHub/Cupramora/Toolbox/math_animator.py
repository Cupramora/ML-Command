# math_animator.py

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from sympy import symbols, sympify, lambdify

x = symbols('x')

class MathAnimator:
    """
    Animates a function over time by plotting its evolution.
    """

    def __init__(self, expr_str: str, x_range=(-5, 5), frames=100):
        self.expr = sympify(expr_str)
        self.f = lambdify(x, self.expr, modules=["numpy"])
        self.x_vals = np.linspace(*x_range, 400)
        self.frames = frames

    def animate_growth(self, interval=50):
        """
        Animates the function growing from 0 to full expression.
        """
        fig, ax = plt.subplots()
        line, = ax.plot([], [], lw=2)
        ax.set_xlim(self.x_vals[0], self.x_vals[-1])
        ax.set_ylim(-10, 10)
        ax.grid(True)

        def init():
            line.set_data([], [])
            return line,

        def update(frame):
            scale = frame / self.frames
            y_vals = scale * self.f(self.x_vals)
            line.set_data(self.x_vals, y_vals)
            return line,

        ani = animation.FuncAnimation(fig, update, frames=self.frames,
                                      init_func=init, blit=True, interval=interval)
        plt.title(f"Animating: {str(self.expr)}")
        plt.show()
