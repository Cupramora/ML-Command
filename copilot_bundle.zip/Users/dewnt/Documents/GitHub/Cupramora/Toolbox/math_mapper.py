# math_mapper.py

class MathMapper:
    """
    Maps math memory capsules to contextual domains:
    - Spatial (e.g., coordinates, terrain)
    - Temporal (e.g., trends, rates)
    - Perceptual (e.g., sensor fields, motion)
    - Command (e.g., task relevance, decision triggers)
    """

    def __init__(self, memory):
        self.memory = memory

    def map_to_context(self, capsule: dict) -> dict:
        """
        Tags a capsule with contextual domains based on its content.
        """
        tags = capsule.get("tags", [])
        payload = capsule.get("payload", {})
        context = []

        if "motion" in tags or "velocity" in payload:
            context.append("temporal")

        if "directional" in tags or "slope" in payload or "gradient" in payload:
            context.append("spatial")

        if "angular" in tags or "field" in capsule.get("source", ""):
            context.append("perceptual")

        if "rate" in payload or "prediction" in payload:
            context.append("command")

        capsule["context"] = list(set(context))
        return capsule

    def map_all(self) -> list:
        """
        Applies context mapping to all stored capsules.
        """
        mapped = []
        for cap in self.memory.memory:
            mapped.append(self.map_to_context(cap))
        return mapped

    def retrieve_by_context(self, domain: str) -> list:
        """
        Returns capsules linked to a specific context domain.
        """
        return [cap for cap in self.memory.memory if domain in cap.get("context", [])]
