# math_memory.py

import time
from collections import defaultdict

class MathMemory:
    """
    Stores and retrieves math capsules over time.
    Supports tagging, time-based recall, and similarity search.
    """

    def __init__(self):
        self.memory = []  # List of capsules
        self.index_by_tag = defaultdict(list)

    def store_capsule(self, capsule: dict):
        """
        Adds a capsule to memory and indexes it by tags.
        """
        capsule["timestamp"] = time.time()
        self.memory.append(capsule)

        for tag in capsule.get("tags", []):
            self.index_by_tag[tag].append(capsule)

    def retrieve_by_tag(self, tag: str, limit: int = 5) -> list:
        """
        Returns recent capsules with a given tag.
        """
        return self.index_by_tag.get(tag, [])[-limit:]

    def retrieve_recent(self, limit: int = 5) -> list:
        """
        Returns the most recent N capsules.
        """
        return sorted(self.memory, key=lambda c: c["timestamp"], reverse=True)[:limit]

    def find_similar(self, capsule: dict, threshold: float = 0.8) -> list:
        """
        Finds capsules with overlapping tags or similar payload keys.
        """
        results = []
        for mem in self.memory:
            shared_tags = set(capsule.get("tags", [])) & set(mem.get("tags", []))
            shared_keys = set(capsule.get("payload", {})) & set(mem.get("payload", {}))
            score = (len(shared_tags) + len(shared_keys)) / max(len(capsule.get("tags", [])) + len(capsule.get("payload", {})), 1)
            if score >= threshold:
                results.append(mem)
        return results
