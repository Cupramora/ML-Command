# capsule_router.py

from perception import process_capsule
from perception_bridge import PerceptionBridge
from capsule_factory import CapsuleFactory

class CapsuleRouter:
    """
    Routes validated capsules to perception, memory, or behavior systems.
    """

    def __init__(self):
        self.factory = CapsuleFactory()
        self.bridge = PerceptionBridge()

    def route(self, capsule_type: str, raw_data: dict):
        capsule = self.factory.create_capsule(capsule_type, raw_data)
        perception_output = process_capsule(capsule)
        self.bridge.process_capsule(capsule)
        return perception_output
