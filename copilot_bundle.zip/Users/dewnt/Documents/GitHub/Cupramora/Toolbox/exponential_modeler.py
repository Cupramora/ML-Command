# exponential_modeler.py

import numpy as np
from scipy.optimize import curve_fit

def exponential_func(x, a, b):
    """Model: y = a * exp(b * x)"""
    return a * np.exp(b * x)

def fit_exponential(x_data: list[float], y_data: list[float]) -> dict | None:
    """
    Fits an exponential model to the data.

    Parameters:
        x_data (list): Independent variable values
        y_data (list): Dependent variable values

    Returns:
        dict: {
            "a": coefficient a,
            "b": exponent base b,
            "model": lambda x: a * exp(b * x),
            "r_squared": goodness of fit
        } or None if fitting fails
    """
    try:
        popt, _ = curve_fit(exponential_func, x_data, y_data, maxfev=10000)
        a, b = popt
        model = lambda x: a * np.exp(b * x)

        # Compute R²
        residuals = y_data - model(np.array(x_data))
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((y_data - np.mean(y_data))**2)
        r_squared = 1 - (ss_res / ss_tot)

        return {"a": a, "b": b, "model": model, "r_squared": r_squared}
    except Exception:
        return None

