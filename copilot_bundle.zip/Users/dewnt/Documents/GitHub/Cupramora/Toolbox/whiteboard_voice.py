# whiteboard_voice.py

from speak import Speak

class WhiteboardVoice:
    """
    Narrates sketches using the shared voice engine.
    """

    def __init__(self):
        self.speaker = Speak()

    def narrate_sketch(self, topic: str, shapes: list[str]):
        intro = f"This sketch is about {topic}."
        if shapes:
            shape_list = ", ".join(shapes)
            detail = f"I see the following shapes: {shape_list}."
        else:
            detail = "No clear shapes were detected."
        self.speaker.say(intro + " " + detail)
