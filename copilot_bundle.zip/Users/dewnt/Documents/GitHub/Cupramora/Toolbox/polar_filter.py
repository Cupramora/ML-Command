# polar_filter.py
# Filter or isolate motion in a given angular sector
