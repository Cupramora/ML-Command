# function_transformer.py

import numpy as np

def shift(f, h=0, k=0):
    """
    Returns a new function g(x) = f(x - h) + k
    Horizontal shift by h, vertical shift by k
    """
    return lambda x: f(x - h) + k

def stretch(f, a=1, b=1):
    """
    Returns a new function g(x) = a * f(b * x)
    Vertical stretch by a, horizontal compression by b
    """
    return lambda x: a * f(b * x)

def reflect(f, over_x=False, over_y=False):
    """
    Reflects the function over x-axis and/or y-axis.
    """
    if over_x and over_y:
        return lambda x: -f(-x)
    elif over_x:
        return lambda x: -f(x)
    elif over_y:
        return lambda x: f(-x)
    return f

def compose(f, g):
    """
    Returns the composition f(g(x))
    """
    return lambda x: f(g(x))
