# sketch_analyzer.py

import cv2
import numpy as np

class SketchAnalyzer:
    """
    Analyzes whiteboard sketches to detect basic geometric shapes and contours.
    """

    def __init__(self, image_path: str):
        self.image_path = image_path
        self.image = cv2.imread(image_path)
        self.gray = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        self.blurred = cv2.GaussianBlur(self.gray, (5, 5), 0)
        self.edges = cv2.Canny(self.blurred, 50, 150)

    def detect_shapes(self) -> list:
        """
        Detects basic shapes (triangle, square, circle, etc.) in the sketch.
        Returns a list of shape names.
        """
        contours, _ = cv2.findContours(self.edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        shapes = []

        for cnt in contours:
            approx = cv2.approxPolyDP(cnt, 0.04 * cv2.arcLength(cnt, True), True)
            sides = len(approx)

            if sides == 3:
                shapes.append("triangle")
            elif sides == 4:
                x, y, w, h = cv2.boundingRect(approx)
                aspect_ratio = w / float(h)
                if 0.95 <= aspect_ratio <= 1.05:
                    shapes.append("square")
                else:
                    shapes.append("rectangle")
            elif sides > 4:
                shapes.append("circle-like")

        return shapes
