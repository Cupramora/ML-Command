# derivative_estimator.py

from sympy import symbols, diff, sympify, lambdify
import numpy as np

x = symbols('x')

def symbolic_derivative(expr_str: str) -> str | None:
    """
    Returns the symbolic derivative of a function string.
    Example: "x**2 + 3*x" → "2*x + 3"
    """
    try:
        expr = sympify(expr_str)
        derivative = diff(expr, x)
        return str(derivative)
    except Exception:
        return None

def numerical_derivative(f_str: str, x_val: float, h: float = 1e-5) -> float | None:
    """
    Estimates the derivative at a point using central difference.
    f_str: function as string (e.g., "x**2 + 3*x")
    x_val: point to evaluate derivative at
    h: step size
    """
    try:
        f = lambdify(x, sympify(f_str), modules=["numpy"])
        return (f(x_val + h) - f(x_val - h)) / (2 * h)
    except Exception:
        return None
