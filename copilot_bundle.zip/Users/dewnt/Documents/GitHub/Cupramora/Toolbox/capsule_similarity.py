# capsule_similarity.py

import numpy as np

class CapsuleSimilarity:
    """
    Compares encoded capsules using cosine similarity or Euclidean distance.
    """

    def cosine_similarity(self, vec1, vec2):
        dot = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        return round(dot / (norm1 * norm2 + 1e-8), 4)

    def euclidean_distance(self, vec1, vec2):
        return round(np.linalg.norm(vec1 - vec2), 4)

    def most_similar(self, target_vec, memory_vectors, top_k=3):
        sims = [
            (i, self.cosine_similarity(target_vec, vec))
            for i, vec in enumerate(memory_vectors)
        ]
        return sorted(sims, key=lambda x: x[1], reverse=True)[:top_k]
