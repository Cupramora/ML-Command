# whiteboard_cleaner.py

import os
from whiteboard_memory import WhiteboardMemory

class WhiteboardCleaner:
    """
    Deletes whiteboard sketches or clears memory selectively.
    """

    def __init__(self):
        self.memory = WhiteboardMemory()

    def delete_sketch(self, path: str) -> bool:
        """
        Deletes a specific sketch file and removes it from memory index.
        """
        try:
            os.remove(path)
            for topic, entries in self.memory.index_by_topic.items():
                self.memory.index_by_topic[topic] = [e for e in entries if e["path"] != path]
            print(f"🗑️ Deleted sketch: {path}")
            return True
        except Exception as e:
            print(f"⚠️ Failed to delete sketch: {e}")
            return False

    def clear_topic(self, topic: str):
        """
        Deletes all sketches under a topic.
        """
        sketches = self.memory.retrieve_by_topic(topic)
        for s in sketches:
            self.delete_sketch(s["path"])
        self.memory.index_by_topic[topic] = []
        print(f"🧼 Cleared all sketches for topic '{topic}'.")

    def wipe_all(self):
        """
        Deletes all sketches and resets memory.
        """
        for topic in self.memory.list_all_topics():
            self.clear_topic(topic)
        print("🧯 Whiteboard memory fully wiped.")
