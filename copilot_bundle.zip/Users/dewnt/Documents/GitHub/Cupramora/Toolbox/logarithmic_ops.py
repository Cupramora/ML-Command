# logarithmic_ops.py

import math

def log_base(x: float, base: float) -> float | None:
    """Computes log base `base` of `x`."""
    if x <= 0 or base <= 0 or base == 1:
        return None
    return math.log(x, base)

def natural_log(x: float) -> float | None:
    """Computes natural logarithm (ln) of x."""
    return log_base(x, math.e)

def common_log(x: float) -> float | None:
    """Computes base-10 logarithm of x."""
    return log_base(x, 10)

def change_of_base(x: float, old_base: float, new_base: float) -> float | None:
    """Converts log base from old_base to new_base."""
    log_x_old = log_base(x, old_base)
    return log_base(x, new_base) if log_x_old is not None else None
