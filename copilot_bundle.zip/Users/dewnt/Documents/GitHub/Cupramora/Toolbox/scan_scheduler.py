# scan_scheduler.py

class ScanScheduler:
    """
    Chooses which scan modules to activate based on task context,
    recent scan history, and adaptive scanner feedback.
    """

    def __init__(self, analyzers: dict, adaptive_scanner):
        """
        Parameters:
            analyzers (dict): Mapping of scan type to callable analyzer
                e.g., {"kinematic": KinematicAnalyzer(), "field": FieldAnalyzer(...)}
            adaptive_scanner: Instance of AdaptiveScanner
        """
        self.analyzers = analyzers
        self.adaptive_scanner = adaptive_scanner
        self.last_scan_type = None

    def schedule(self, context: dict, current_state: dict) -> dict:
        """
        Decides which scan to run based on context and change.

        Parameters:
            context (dict): Task or environment context (e.g., {"task": "navigation"})
            current_state (dict): Sensor snapshot for adaptive scan check

        Returns:
            dict: {
                "scan_type": str,
                "result": analyzer output or None
            }
        """
        if not self.adaptive_scanner.should_scan(current_state):
            return {"scan_type": None, "result": None}

        task = context.get("task", "")
        scan_type = self._choose_scan_type(task)

        analyzer = self.analyzers.get(scan_type)
        if analyzer:
            result = analyzer.analyze() if hasattr(analyzer, "analyze") else None
            self.last_scan_type = scan_type
            return {"scan_type": scan_type, "result": result}

        return {"scan_type": None, "result": None}

    def _choose_scan_type(self, task: str) -> str:
        """
        Maps task context to preferred scan type.
        """
        if "motion" in task or "tracking" in task:
            return "kinematic"
        elif "terrain" in task or "navigation" in task:
            return "topographic"
        elif "environment" in task or "heat" in task:
            return "field"
        else:
            return "kinematic"  # Default fallback
