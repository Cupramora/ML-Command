# whiteboard_feedback.py

import time

class WhiteboardFeedback:
    """
    Collects learner feedback on whiteboard sketches.
    """

    def __init__(self):
        self.feedback_log = []

    def submit_feedback(self, sketch_path: str, clarity: float, comment: str = ""):
        entry = {
            "timestamp": time.strftime("%Y%m%d-%H%M%S"),
            "sketch_path": sketch_path,
            "clarity": clarity,
            "comment": comment
        }
        self.feedback_log.append(entry)
        print(f"📝 Feedback recorded for {sketch_path}: Clarity={clarity}, Comment='{comment}'")

    def recent_feedback(self, limit: int = 5):
        print(f"\n📋 Last {limit} feedback entries:")
        for f in self.feedback_log[-limit:]:
            print(f"  - {f['timestamp']} | Clarity: {f['clarity']} | Comment: {f['comment']}")
