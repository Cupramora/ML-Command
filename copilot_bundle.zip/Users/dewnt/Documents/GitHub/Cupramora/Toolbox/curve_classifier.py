# curve_classifier.py

import numpy as np

def classify_curve(x: list[float], y: list[float]) -> str:
    """
    Attempts to classify the shape of a curve based on y-values.

    Returns:
        str: One of ["linear", "quadratic", "exponential", "logarithmic", "unknown"]
    """
    try:
        x_np = np.array(x)
        y_np = np.array(y)

        # Linear check
        if np.allclose(np.diff(y_np), np.diff(y_np)[0], atol=1e-2):
            return "linear"

        # Quadratic check
        second_diff = np.diff(y_np, n=2)
        if np.allclose(second_diff, second_diff[0], atol=1e-2):
            return "quadratic"

        # Exponential check
        log_y = np.log(y_np + 1e-8)
        if np.allclose(np.diff(log_y), np.diff(log_y)[0], atol=1e-2):
            return "exponential"

        # Logarithmic check
        log_x = np.log(x_np + 1e-8)
        if np.allclose(np.diff(y_np), np.diff(log_x), atol=1e-2):
            return "logarithmic"

        return "unknown"
    except Exception:
        return "unknown"
