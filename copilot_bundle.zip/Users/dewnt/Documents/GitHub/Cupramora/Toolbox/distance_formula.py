# distance_formula.py
# Straight-line distance between 2D or 3D points
