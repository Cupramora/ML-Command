# capsule_journal.py

import time
from datetime import datetime

class CapsuleJournal:
    """
    Logs daily summaries of capsule activity, including emotional trends and key behaviors.
    """

    def __init__(self):
        self.entries = {}

    def summarize_day(self, capsules: list):
        """
        Accepts a list of PerceptionCapsule objects and logs a daily summary.
        """
        if not capsules:
            return "No capsules to summarize."

        date_key = datetime.now().strftime("%Y-%m-%d")
        emotions = {}
        behaviors = {}
        tags = []

        for cap in capsules:
            for emo, val in cap.emotion_vector.items():
                emotions[emo] = emotions.get(emo, 0) + val
            behaviors[cap.behavior] = behaviors.get(cap.behavior, 0) + 1
            if hasattr(cap, "tags"):
                tags.extend(cap.tags)

        dominant_emotion = max(emotions.items(), key=lambda x: x[1])[0] if emotions else "neutral"
        top_behavior = max(behaviors.items(), key=lambda x: x[1])[0] if behaviors else "none"

        summary = {
            "timestamp": time.time(),
            "dominant_emotion": dominant_emotion,
            "top_behavior": top_behavior,
            "unique_behaviors": len(behaviors),
            "tags": list(set(tags))
        }

        self.entries[date_key] = summary
        return summary

    def get_entry(self, date_str: str):
        return self.entries.get(date_str, "No entry for that date.")

    def recent_entries(self, limit=3):
        keys = sorted(self.entries.keys(), reverse=True)
        return {k: self.entries[k] for k in keys[:limit]}
