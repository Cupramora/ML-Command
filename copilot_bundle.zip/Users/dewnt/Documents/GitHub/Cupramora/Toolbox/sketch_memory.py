# sketch_memory.py

import time
from collections import defaultdict

class SketchMemory:
    """
    Stores comparisons between sketches with similarity scores and notes.
    """

    def __init__(self):
        self.comparisons = []
        self.index_by_topic = defaultdict(list)

    def log_comparison(self, path1: str, path2: str, similarity: float, method: str, topic: str = "", notes: str = ""):
        entry = {
            "timestamp": time.strftime("%Y%m%d-%H%M%S"),
            "sketch_1": path1,
            "sketch_2": path2,
            "similarity": round(similarity, 4),
            "method": method,
            "topic": topic,
            "notes": notes
        }
        self.comparisons.append(entry)
        if topic:
            self.index_by_topic[topic].append(entry)
        print(f"🧠 Logged comparison ({method}): {similarity} between {path1} and {path2}")
        return entry

    def get_recent(self, limit: int = 5) -> list:
        return self.comparisons[-limit:]

    def get_by_topic(self, topic: str) -> list:
        return self.index_by_topic.get(topic, [])
