# kinematic_analyzer.py

from distance_2d import distance_2d
from vector_ops import magnitude

class KinematicAnalyzer:
    """
    Tracks position, velocity, and acceleration of keypoints over time.
    Assumes 2D points and uniform time steps (dt).
    """

    def __init__(self, dt: float = 1.0):
        self.dt = dt
        self.history = []  # List of point lists: [[(x1, y1), (x2, y2), ...], ...]

    def update(self, points: list[tuple]) -> dict:
        """
        Adds a new frame of keypoints and computes kinematic data.

        Parameters:
            points (list of tuples): Current frame's 2D keypoints

        Returns:
            dict: {
                "velocity": [v1, v2, ...],
                "acceleration": [a1, a2, ...]
            }
        """
        self.history.append(points)
        n = len(self.history)

        velocity = []
        acceleration = []

        if n >= 2:
            prev = self.history[-2]
            velocity = [
                distance_2d(p, q) / self.dt
                for p, q in zip(prev, points)
            ]

        if n >= 3:
            prev_v = [
                distance_2d(p, q) / self.dt
                for p, q in zip(self.history[-3], self.history[-2])
            ]
            acceleration = [
                (v2 - v1) / self.dt
                for v1, v2 in zip(prev_v, velocity)
            ]

        return {
            "velocity": velocity if velocity else None,
            "acceleration": acceleration if acceleration else None
        }
