# simplify_and_factor.py

from sympy import symbols, simplify, factor

x = symbols('x')  # You can generalize this later

def simplify_expr(expr_str: str) -> str:
    """
    Simplifies an algebraic expression string.
    Example: "x**2 + 2*x + 1" → "x**2 + 2*x + 1"
    """
    expr = simplify(expr_str)
    return str(expr)

def factor_expr(expr_str: str) -> str:
    """
    Factors a polynomial expression string.
    Example: "x**2 + 2*x + 1" → "(x + 1)**2"
    """
    expr = factor(expr_str)
    return str(expr)
