# to_polar.py
# Convert (x,y) to (r,theta)

import math

def to_polar(x: float, y: float) -> tuple:
    """
    Converts Cartesian coordinates (x, y) to polar form (r, theta).

    Returns:
        tuple: (r, theta) where r is the radius and theta is in degrees
    """
    r = math.hypot(x, y)
    theta = math.degrees(math.atan2(y, x))
    return (r, theta)