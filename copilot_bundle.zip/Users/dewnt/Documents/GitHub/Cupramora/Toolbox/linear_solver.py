# linear_solver.py

def solve_linear(a: float, b: float) -> float | None:
    """
    Solves a basic linear equation of the form:
        ax + b = 0

    Parameters:
        a (float): Coefficient of x
        b (float): Constant term

    Returns:
        float | None: Solution for x if solvable, otherwise None (degenerate)
    """
    if a == 0:
        return None  # No solution (or infinite solutions if b is also 0)
    return -b / a
