# adaptive_scanner.py

class AdaptiveScanner:
    """
    Decides when to trigger a scan based on change detection, confidence decay,
    and historical scan utility. Inspired by PID control.
    """

    def __init__(self, target_change=0.1, kp=1.0, ki=0.1, kd=0.05):
        self.target_change = target_change  # Desired minimum change to justify scan
        self.kp = kp
        self.ki = ki
        self.kd = kd

        self.prev_change = 0.0
        self.integral = 0.0
        self.last_scan_result = None
        self.scan_history = []

    def should_scan(self, current_state: dict) -> bool:
        """
        Determines whether a scan should be triggered.

        Parameters:
            current_state (dict): Current sensor or perception state

        Returns:
            bool: True if scan is recommended
        """
        if self.last_scan_result is None:
            self.last_scan_result = current_state
            return True  # Always scan on first run

        # Compute change magnitude (simple diff metric)
        delta = sum(
            abs(current_state.get(k, 0) - self.last_scan_result.get(k, 0))
            for k in current_state
        ) / max(len(current_state), 1)

        # PID-style decision
        error = delta - self.target_change
        self.integral += error
        derivative = error - self.prev_change
        self.prev_change = error

        score = self.kp * error + self.ki * self.integral + self.kd * derivative

        if score > 0:
            self.last_scan_result = current_state
            self.scan_history.append((delta, True))
            return True
        else:
            self.scan_history.append((delta, False))
            return False
