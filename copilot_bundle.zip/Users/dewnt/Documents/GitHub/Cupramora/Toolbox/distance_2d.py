# distance_2d.py
# Computes the straight-line distance between 2D points

import math

def distance_2d(p1: tuple, p2: tuple) -> float:
    """
    Calculates the straight-line (Euclidean) distance between two 2D points.

    Parameters:
        p1 (tuple): (x1, y1) coordinates of the first point
        p2 (tuple): (x2, y2) coordinates of the second point

    Returns:
        float: Distance between p1 and p2
    """
    x1, y1 = p1
    x2, y2 = p2
    return math.hypot(x2 - x1, y2 - y1)
