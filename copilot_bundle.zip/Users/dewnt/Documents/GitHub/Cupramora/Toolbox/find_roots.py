# find_roots.py

import numpy as np

def find_roots(coeffs: list[float]) -> list[float]:
    """
    Finds the real roots of a polynomial given its coefficients.

    Parameters:
        coeffs (list): Polynomial coefficients from highest to lowest degree

    Returns:
        list of floats: Real roots only
    """
    roots = np.roots(coeffs)
    return [r.real for r in roots if np.isreal(r)]
