# triangle_solver.py
# Given side/angle combos, fills in the missing pieces

import math

def solve_triangle(a=None, b=None, c=None, A=None, B=None, C=None):
    """
    Solves a triangle given any 3 known values (sides or angles),
    using standard trigonometric rules (Law of Sines, Cosines).

    Angles in degrees. Returns dict of all sides (a, b, c) and angles (A, B, C).
    Known values must include at least one side.

    Parameters:
        a, b, c: Side lengths
        A, B, C: Angles in degrees (opposite sides a, b, c respectively)

    Returns:
        dict: Complete triangle specification with sides and angles
    """
    # Convert angles to radians for internal use
    def deg2rad(deg): return math.radians(deg)
    def rad2deg(rad): return math.degrees(rad)

    known = {'a': a, 'b': b, 'c': c, 'A': A, 'B': B, 'C': C}

    # At least one side must be provided
    if all(v is None for v in (a, b, c)):
        raise ValueError("At least one side length is required.")

    # Priority order: SSS > SAS > ASA/AAS > SSA
    # Start with Law of Cosines if 3 sides are known
    if a and b and c:
        A = rad2deg(math.acos((b**2 + c**2 - a**2) / (2*b*c)))
        B = rad2deg(math.acos((a**2 + c**2 - b**2) / (2*a*c)))
        C = 180 - A - B

    # Law of Sines
    elif a and A and B:
        b = (a * math.sin(deg2rad(B))) / math.sin(deg2rad(A))
        C = 180 - A - B
        c = (a * math.sin(deg2rad(C))) / math.sin(deg2rad(A))
    elif a and A and C:
        B = 180 - A - C
       