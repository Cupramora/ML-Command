# find_roots_symbolic.py

from sympy import symbols, solve, simplify
from sympy.parsing.sympy_parser import parse_expr

x = symbols('x')  # Default variable

def find_roots_symbolic(expr_str: str, var_str: str = "x") -> list:
    """
    Finds symbolic roots of a univariate polynomial expression.

    Parameters:
        expr_str (str): The polynomial as a string (e.g., "x**2 - 5*x + 6")
        var_str (str): The variable to solve for (default: "x")

    Returns:
        list: List of symbolic roots (can include radicals or fractions)
    """
    try:
        var = symbols(var_str)
        expr = parse_expr(expr_str)
        roots = solve(expr, var)
        return [simplify(r) for r in roots]
    except Exception:
        return []
