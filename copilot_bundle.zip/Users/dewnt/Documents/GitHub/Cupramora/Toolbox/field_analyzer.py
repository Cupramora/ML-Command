# field_analyzer.py

import numpy as np

class FieldAnalyzer:
    """
    Analyzes 2D scalar fields (e.g., temperature, light, pressure) to detect
    gradients, hotspots, and directional flow.
    """

    def __init__(self, field: np.ndarray, dx: float = 1.0, dy: float = 1.0):
        """
        Parameters:
            field (np.ndarray): 2D array of scalar values
            dx (float): horizontal resolution
            dy (float): vertical resolution
        """
        self.field = field
        self.dx = dx
        self.dy = dy

    def compute_gradient(self) -> dict:
        """
        Computes the gradient (partial derivatives) of the field.

        Returns:
            dict: {
                "grad_x": ∂field/∂x,
                "grad_y": ∂field/∂y,
                "magnitude": gradient magnitude,
                "direction": gradient angle in degrees
            }
        """
        grad_y, grad_x = np.gradient(self.field, self.dy, self.dx)
        magnitude = np.hypot(grad_x, grad_y)
        direction = np.degrees(np.arctan2(grad_y, grad_x))

        return {
            "grad_x": grad_x,
            "grad_y": grad_y,
            "magnitude": magnitude,
            "direction": direction
        }

    def detect_hotspots(self, threshold: float) -> np.ndarray:
        """
        Returns a boolean mask of where the field exceeds a threshold.
        """
        return self.field > threshold
