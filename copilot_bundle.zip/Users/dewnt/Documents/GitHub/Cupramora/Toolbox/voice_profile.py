# voice_profile.py

from speak import Speak

class VoiceProfile:
    """
    Manages different voice styles by adjusting rate, pitch, and voice ID.
    """

    def __init__(self):
        self.profiles = {
            "default": {"rate": 180, "voice_id": 0},
            "teacher": {"rate": 170, "voice_id": 0},
            "narrator": {"rate": 150, "voice_id": 1},
            "peer": {"rate": 200, "voice_id": 0}
        }
        self.current = "default"
        self.speaker = Speak(**self.profiles[self.current])

    def set_profile(self, profile_name: str):
        if profile_name in self.profiles:
            self.current = profile_name
            config = self.profiles[profile_name]
            self.speaker = Speak(**config)
            self.speaker.say(f"Voice profile set to {profile_name}.")
        else:
            self.speaker.say("That voice profile does not exist.")

    def say(self, text: str):
        self.speaker.say(text)
