# tutor_memory.py

import time
from collections import defaultdict

class TutorMemory:
    """
    Stores logs of tutoring sessions, including strategy, topic, feedback, and clarity.
    Enables reflection, pattern recognition, and long-term adaptation.
    """

    def __init__(self):
        self.sessions = []
        self.index_by_topic = defaultdict(list)

    def log_session(self, topic: str, strategy: int, clarity: float, feedback: str = ""):
        """
        Records a tutoring session.

        Parameters:
            topic (str): Subject or concept taught
            strategy (int): Strategy level used (1–3)
            clarity (float): Learner clarity score (0–1)
            feedback (str): Optional learner comment
        """
        entry = {
            "timestamp": time.time(),
            "topic": topic,
            "strategy": strategy,
            "clarity": clarity,
            "feedback": feedback
        }
        self.sessions.append(entry)
        self.index_by_topic[topic].append(entry)

    def retrieve_by_topic(self, topic: str, limit: int = 5) -> list:
        return self.index_by_topic.get(topic, [])[-limit:]

    def summarize_topic(self, topic: str) -> dict:
        """
        Returns average clarity and most used strategy for a topic.
        """
        entries = self.index_by_topic.get(topic, [])
        if not entries:
            return {}

        avg_clarity = sum(e["clarity"] for e in entries) / len(entries)
        strategy_counts = defaultdict(int)
        for e in entries:
            strategy_counts[e["strategy"]] += 1
        most_used = max(strategy_counts, key=strategy_counts.get)

        return {
            "topic": topic,
            "avg_clarity": round(avg_clarity, 3),
            "most_used_strategy": most_used,
            "sessions": len(entries)
        }
