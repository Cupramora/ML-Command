# capsule_registry.py

class CapsuleRegistry:
    """
    Registers and validates capsule types across sensory and cognitive modules.
    """

    def __init__(self):
        self.registry = {}

    def register_capsule_type(self, name: str, required_fields: list[str], source: str = "", description: str = ""):
        """
        Registers a new capsule type with required fields and optional metadata.
        """
        self.registry[name] = {
            "required_fields": required_fields,
            "source": source,
            "description": description
        }

    def validate_capsule(self, capsule: dict, capsule_type: str) -> bool:
        """
        Checks if a capsule contains all required fields for its type.
        """
        if capsule_type not in self.registry:
            raise ValueError(f"Capsule type '{capsule_type}' not registered.")

        required = self.registry[capsule_type]["required_fields"]
        missing = [field for field in required if field not in capsule]

        if missing:
            print(f"Validation failed: missing fields {missing}")
            return False

        return True

    def list_capsule_types(self) -> list:
        return list(self.registry.keys())

    def describe_capsule_type(self, capsule_type: str) -> dict:
        return self.registry.get(capsule_type, {})
