# topographic_analyzer.py

import numpy as np
from topocalc.gradient import gradient_d8

class TopographicAnalyzer:
    """
    Analyzes digital elevation models (DEMs) to extract slope and aspect.
    Uses finite difference methods to estimate terrain shape.
    """

    def __init__(self, dem_array: np.ndarray, dx: float = 1.0, dy: float = 1.0):
        """
        Parameters:
            dem_array (np.ndarray): 2D elevation grid
            dx (float): horizontal resolution (e.g., meters per pixel)
            dy (float): vertical resolution
        """
        self.dem = dem_array
        self.dx = dx
        self.dy = dy

    def analyze(self) -> dict:
        """
        Computes slope and aspect from the DEM.

        Returns:
            dict: {
                "slope": 2D array of slope in degrees,
                "aspect": 2D array of aspect in degrees
            }
        """
        slope, aspect = gradient_d8(self.dem, self.dx, self.dy)
        return {
            "slope": slope,
            "aspect": aspect
        }
