# math_visualizer.py

import numpy as np
import matplotlib.pyplot as plt
from sympy import sympify, lambdify, symbols

x = symbols('x')

class MathVisualizer:
    """
    Visualizes mathematical functions, derivatives, and integrals.
    """

    def __init__(self, x_range=(-10, 10), resolution=400):
        self.x_range = x_range
        self.resolution = resolution

    def plot_function(self, expr_str: str, label: str = "f(x)", color: str = "blue"):
        """
        Plots a symbolic function over the x range.
        """
        try:
            expr = sympify(expr_str)
            f = lambdify(x, expr, modules=["numpy"])
            x_vals = np.linspace(*self.x_range, self.resolution)
            y_vals = f(x_vals)

            plt.plot(x_vals, y_vals, label=label, color=color)
        except Exception as e:
            print("Plot error:", e)

    def shade_area(self, expr_str: str, a: float, b: float, color: str = "orange", alpha: float = 0.3):
        """
        Shades the area under the curve between a and b.
        """
        try:
            expr = sympify(expr_str)
            f = lambdify(x, expr, modules=["numpy"])
            x_vals = np.linspace(a, b, self.resolution)
            y_vals = f(x_vals)

            plt.fill_between(x_vals, y_vals, color=color, alpha=alpha)
        except Exception as e:
            print("Shading error:", e)

    def show(self, title="Math Visualization"):
        plt.title(title)
        plt.xlabel("x")
        plt.ylabel("y")
        plt.grid(True)
        plt.legend()
        plt.show()
