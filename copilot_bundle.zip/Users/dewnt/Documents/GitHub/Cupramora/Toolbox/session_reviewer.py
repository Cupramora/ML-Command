# session_reviewer.py

from whiteboard_session import WhiteboardSession

class SessionReviewer:
    """
    Allows browsing and filtering of past whiteboard sessions.
    """

    def __init__(self, session_tracker: WhiteboardSession):
        self.session_tracker = session_tracker

    def list_recent_sessions(self, limit: int = 5):
        sessions = self.session_tracker.get_recent_sessions(limit)
        print(f"\n🕰️ Last {len(sessions)} whiteboard sessions:")
        for s in sessions:
            print(f"  - [{s['timestamp']}] Topic: {s['topic']}, Duration: {s['duration_sec']}s")
            print(f"    Shapes: {s['shapes_detected']}, Notes: {s['notes']}")
            print(f"    File: {s['sketch_path']}")

    def filter_by_shape(self, shape: str):
        matches = [s for s in self.session_tracker.sessions if shape in s.get("shapes_detected", [])]
        print(f"\n🔍 Sessions with shape '{shape}':")
        for s in matches:
            print(f"  - {s['timestamp']} | Topic: {s['topic']} | File: {s['sketch_path']}")
