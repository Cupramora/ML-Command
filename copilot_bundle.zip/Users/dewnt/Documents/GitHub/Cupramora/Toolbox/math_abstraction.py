# math_abstraction.py

from collections import defaultdict

class MathAbstraction:
    """
    Extracts abstract patterns from math capsules.
    Groups similar structures and proposes general forms.
    """

    def __init__(self):
        self.patterns = defaultdict(list)

    def abstract_capsule(self, capsule: dict) -> str:
        """
        Converts a capsule into a symbolic pattern string.
        Example: {"velocity": 3.2, "acceleration": 1.1} → "motion(v, a)"
        """
        tags = capsule.get("tags", [])
        payload = capsule.get("payload", {})
        if "motion" in tags:
            keys = sorted(payload.keys())
            return f"motion({', '.join(k[0] for k in keys)})"
        elif "directional" in tags:
            return "direction(θ)"
        elif "exponential" in tags:
            return "growth(a·e^(bx))"
        return "unknown()"

    def group_by_pattern(self, capsules: list) -> dict:
        """
        Groups capsules by their abstracted pattern.
        """
        for cap in capsules:
            pattern = self.abstract_capsule(cap)
            self.patterns[pattern].append(cap)
        return dict(self.patterns)
