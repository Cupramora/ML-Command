# whiteboard_memory.py

import os
import time
from collections import defaultdict
from PIL import Image

class WhiteboardMemory:
    """
    Stores and retrieves whiteboard captures with metadata.
    Supports tagging, topic indexing, and timestamped recall.
    """

    def __init__(self, save_dir="whiteboard_logs"):
        self.save_dir = save_dir
        os.makedirs(self.save_dir, exist_ok=True)
        self.index_by_topic = defaultdict(list)

    def save_sketch(self, image_path: str, topic: str, notes: str = "") -> dict:
        """
        Archives a whiteboard image with topic and optional notes.
        """
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"{topic}_{timestamp}.png"
        dest_path = os.path.join(self.save_dir, filename)
        Image.open(image_path).save(dest_path)

        entry = {
            "path": dest_path,
            "topic": topic,
            "timestamp": timestamp,
            "notes": notes
        }
        self.index_by_topic[topic].append(entry)
        return entry

    def retrieve_by_topic(self, topic: str, limit: int = 5) -> list:
        """
        Returns recent sketches for a given topic.
        """
        return self.index_by_topic.get(topic, [])[-limit:]

    def list_all_topics(self) -> list:
        return list(self.index_by_topic.keys())
