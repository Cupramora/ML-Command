# math_filter.py

class MathFilter:
    """
    Filters and categorizes math capsules based on tags or payload content.
    """

    def __init__(self):
        self.categories = {
            "motion": [],
            "directional": [],
            "angular": [],
            "high_magnitude": [],
            "uncategorized": []
        }

    def process_capsules(self, capsules: list):
        """
        Sorts capsules into categories based on tags.
        """
        for cap in capsules:
            matched = False
            for tag in cap.get("tags", []):
                if tag in self.categories:
                    self.categories[tag].append(cap)
                    matched = True
            if not matched:
                self.categories["uncategorized"].append(cap)

    def get_category(self, name: str) -> list:
        return self.categories.get(name, [])
