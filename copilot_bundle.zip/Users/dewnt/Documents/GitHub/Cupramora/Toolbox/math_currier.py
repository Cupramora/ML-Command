# math_currier.py

class MathCurrier:
    """
    Collects math outputs from various modules and packages them into
    standardized capsules for downstream perception or command use.
    """

    def __init__(self):
        self.capsules = []

    def collect(self, source: str, data: dict):
        """
        Wraps math data into a capsule.

        Parameters:
            source (str): Origin module (e.g., "vector_ops", "field_analyzer")
            data (dict): Raw output from the math module
        """
        capsule = {
            "source": source,
            "payload": data,
            "tags": self._generate_tags(data)
        }
        self.capsules.append(capsule)

    def _generate_tags(self, data: dict) -> list:
        """
        Creates semantic tags based on keys or values in the data.
        """
        tags = []
        for key in data:
            if "angle" in key: tags.append("angular")
            if "slope" in key or "gradient" in key: tags.append("directional")
            if "velocity" in key or "acceleration" in key: tags.append("motion")
            if isinstance(data[key], (int, float)) and abs(data[key]) > 1000:
                tags.append("high_magnitude")
        return list(set(tags))

    def export_capsules(self) -> list:
        """Returns all collected capsules."""
        return self.capsules
