# limit_estimator.py

from sympy import symbols, limit, sympify, oo

x = symbols('x')

def estimate_limit(expr_str: str, approach: float | str, direction: str = "") -> float | str | None:
    """
    Estimates the limit of a function as x approaches a value.

    Parameters:
        expr_str (str): The expression as a string (e.g., "sin(x)/x")
        approach (float | str): The value x approaches (e.g., 0, "oo", "-oo")
        direction (str): Optional direction: "", "+", or "-"

    Returns:
        float | str | None: The estimated limit or symbolic result
    """
    try:
        expr = sympify(expr_str)
        val = {"oo": oo, "-oo": -oo}.get(str(approach), approach)
        return limit(expr, x, val, dir=direction)
    except Exception:
        return None
