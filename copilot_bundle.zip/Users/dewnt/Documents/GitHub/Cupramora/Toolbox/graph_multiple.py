# graph_multiple.py

import numpy as np
import matplotlib.pyplot as plt

def graph_multiple(polys: list[list[float]], x_range=(-10, 10), steps=400):
    """
    Plots multiple polynomials on the same graph.

    Parameters:
        polys (list of lists): Each sublist is a polynomial's coefficients
        x_range (tuple): (min, max) x-axis range
        steps (int): Number of x points to evaluate
    """
    x = np.linspace(x_range[0], x_range[1], steps)
    for coeffs in polys:
        y = np.polyval(coeffs, x)
        label = "y = " + " + ".join(f"{c}x^{i}" for i, c in enumerate(reversed(coeffs)))
        plt.plot(x, y, label=label)

    plt.axhline(0, color='gray', lw=0.5)
    plt.axvline(0, color='gray', lw=0.5)
    plt.title("Multiple Polynomial Graphs")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.grid(True)
    plt.legend()
    plt.show()
