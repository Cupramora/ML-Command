# angle_between_points.py
# Takes three coordinates, returns interior angle

import math

def angle_between_points(a: tuple, b: tuple, c: tuple) -> float:
    """
    Calculates the angle ABC (in degrees) formed by three 2D points.

    Parameters:
        a (tuple): First point (x, y)
        b (tuple): Vertex point (x, y) - the angle is formed at this point
        c (tuple): Third point (x, y)

    Returns:
        float: Angle ABC in degrees, between 0 and 180
    """
    def vector(p1, p2):
        return (p2[0] - p1[0], p2[1] - p1[1])

    def dot_product(v1, v2):
        return v1[0]*v2[0] + v1[1]*v2[1]

    def magnitude(v):
        return math.hypot(v[0], v[1])

    ab = vector(b, a)
    cb = vector(b, c)

    dot = dot_product(ab, cb)
    mag_ab = magnitude(ab)
    mag_cb = magnitude(cb)

    if mag_ab == 0 or mag_cb == 0:
        return 0.0  # Degenerate case

    cos_angle = max(min(dot / (mag_ab * mag_cb), 1.0), -1.0)
    angle_rad = math.acos(cos_angle)
    return math.degrees(angle_rad)