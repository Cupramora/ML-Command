# capsule_reflector.py

class CapsuleReflector:
    """
    Summarizes patterns and insights from capsule memory.
    """

    def __init__(self, long_term_memory):
        self.memory = long_term_memory

    def summarize_tags(self):
        tag_counts = {}
        for entry in self.memory.entries:
            for tag in entry.get("tags", []):
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        return sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)

    def reflect_on_behavior(self, behavior_name):
        matches = [
            e for e in self.memory.entries
            if e["capsule"].behavior == behavior_name
        ]
        if not matches:
            return f"No long-term memory found for behavior '{behavior_name}'."

        avg_sig = sum(e["significance"] for e in matches) / len(matches)
        return f"Behavior '{behavior_name}' occurred {len(matches)} times with average significance {round(avg_sig, 3)}."
