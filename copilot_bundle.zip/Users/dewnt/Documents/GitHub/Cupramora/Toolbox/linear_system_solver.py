# linear_system_solver.py

import numpy as np

def solve_linear_system(coeff_matrix: list[list[float]], constants: list[float]) -> list[float] | None:
    """
    Solves a system of linear equations represented as Ax = b.

    Parameters:
        coeff_matrix (list of lists): Coefficient matrix A (n x n)
        constants (list): Constant vector b (length n)

    Returns:
        list of floats: Solution vector x, or None if no unique solution exists
    """
    try:
        A = np.array(coeff_matrix, dtype=float)
        b = np.array(constants, dtype=float)
        x = np.linalg.solve(A, b)
        return x.tolist()
    except np.linalg.LinAlgError:
        return None  # Singular matrix or no unique solution
