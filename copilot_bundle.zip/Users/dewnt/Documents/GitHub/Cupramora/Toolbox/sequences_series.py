
# sequences_series.py

def arithmetic_sequence(a1: float, d: float, n: int) -> list[float]:
    """Generates an arithmetic sequence of n terms."""
    return [a1 + i * d for i in range(n)]

def arithmetic_sum(a1: float, d: float, n: int) -> float:
    """Computes the sum of the first n terms of an arithmetic sequence."""
    return (n / 2) * (2 * a1 + (n - 1) * d)

def geometric_sequence(a1: float, r: float, n: int) -> list[float]:
    """Generates a geometric sequence of n terms."""
    return [a1 * (r ** i) for i in range(n)]

def geometric_sum(a1: float, r: float, n: int) -> float:
    """Computes the sum of the first n terms of a geometric sequence."""
    if r == 1:
        return a1 * n
    return a1 * (1 - r ** n) / (1 - r)

def infinite_geometric_sum(a1: float, r: float) -> float | None:
    """Returns the sum of an infinite geometric series if |r| < 1."""
    if abs(r) >= 1:
        return None
    return a1 / (1 - r)

