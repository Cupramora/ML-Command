# linear_organizer.py

import numpy as np

class LinearOrganizer:
    """
    A PID-inspired array organizer that learns to reshape and cluster
    incoming 1D arrays into optimal 2D matrix forms over time.
    """

    def __init__(self, target_cols=3):
        self.target_cols = target_cols
        self.history = []
        self.error_integral = 0
        self.prev_error = 0

    def organize(self, array: list[float]) -> np.ndarray:
        """
        Reshapes a 1D array into a 2D matrix with adaptive column count.

        Parameters:
            array (list): Flat list of numbers

        Returns:
            np.ndarray: Reshaped matrix
        """
        n = len(array)
        error = (n % self.target_cols)
        self.error_integral += error
        derivative = error - self.prev_error
        self.prev_error = error

        # PID-inspired adjustment (tune these gains)
        kp, ki, kd = 0.1, 0.01, 0.05
        adjustment = int(round(kp * error + ki * self.error_integral + kd * derivative))

        new_cols = max(1, self.target_cols - adjustment)
        rows = int(np.ceil(n / new_cols))
        padded = array + [0] * (rows * new_cols - n)

        matrix = np.array(padded).reshape((rows, new_cols))
        self.history.append((n, new_cols))
        return matrix
