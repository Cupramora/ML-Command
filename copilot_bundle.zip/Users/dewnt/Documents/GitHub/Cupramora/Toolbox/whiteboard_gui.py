# whiteboard_gui.py

import tkinter as tk
from tkinter import filedialog, messagebox
from whiteboard_interface import WhiteboardInterface
from whiteboard_dashboard import WhiteboardDashboard

class WhiteboardGUI:
    """
    GUI wrapper for launching and managing whiteboard sessions.
    """

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Whiteboard Control Panel")
        self.dashboard = WhiteboardDashboard()

        self._build_ui()

    def _build_ui(self):
        tk.Label(self.root, text="Whiteboard Topic:").pack()
        self.topic_entry = tk.Entry(self.root, width=40)
        self.topic_entry.pack(pady=5)

        tk.Button(self.root, text="Start Session", command=self.start_session).pack(pady=2)
        tk.Button(self.root, text="End Session", command=self.end_session).pack(pady=2)
        tk.Button(self.root, text="Review Sessions", command=self.dashboard.recent_sessions).pack(pady=2)
        tk.Button(self.root, text="Show Topics", command=self.dashboard.show_topics).pack(pady=2)
        tk.Button(self.root, text="Exit", command=self.root.quit).pack(pady=10)

    def start_session(self):
        topic = self.topic_entry.get().strip()
        if topic:
            self.dashboard.start_session(topic)
            board = WhiteboardInterface()
            board.run()
        else:
            messagebox.showwarning("Missing Topic", "Please enter a topic before starting.")

    def end_session(self):
        topic = self.topic_entry.get().strip()
        if topic:
            self.dashboard.end_session("whiteboard_capture.png", notes="Saved via GUI")
        else:
            messagebox.showwarning("Missing Topic", "Please enter a topic before ending session.")

    def run(self):
        self.root.mainloop()
