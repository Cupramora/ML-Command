# inequality_checker.py

def check_inequality(expr: str, variables: dict = {}) -> bool | None:
    """
    Evaluates an inequality expression with optional variable bindings.

    Parameters:
        expr (str): Inequality string (e.g., "2*x + 1 > 5")
        variables (dict): Variable values (e.g., {"x": 3})

    Returns:
        bool | None: True if inequality holds, False if not, None if invalid
    """
    try:
        return eval(expr, {"__builtins__": None}, variables)
    except Exception:
        return None
