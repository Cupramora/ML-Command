# vector_ops.py

import math

def magnitude(v: tuple) -> float:
    """Returns the length of vector v = (x, y)."""
    return math.hypot(v[0], v[1])

def dot_product(v1: tuple, v2: tuple) -> float:
    """Computes the dot product of two vectors."""
    return v1[0]*v2[0] + v1[1]*v2[1]

def angle_between(v1: tuple, v2: tuple) -> float:
    """
    Calculates the angle between two vectors in degrees.
    Returns 0.0 if either vector is zero-length.
    """
    mag1 = magnitude(v1)
    mag2 = magnitude(v2)
    if mag1 == 0 or mag2 == 0:
        return 0.0
    cos_theta = dot_product(v1, v2) / (mag1 * mag2)
    cos_theta = max(min(cos_theta, 1.0), -1.0)
    return math.degrees(math.acos(cos_theta))

def normalize(v: tuple) -> tuple:
    """
    Returns the unit vector of the input.
    If vector is zero, returns (0.0, 0.0).
    """
    mag = magnitude(v)
    if mag == 0:
        return (0.0, 0.0)
    return (v[0]/mag, v[1]/mag)

def scale(v: tuple, scalar: float) -> tuple:
    """Scales a vector by a given factor."""
    return (v[0] * scalar, v[1] * scalar)
