# evaluate_systems.py

def evaluate_system(conditions: list[str], variables: dict = {}) -> bool | None:
    """
    Evaluates a list of inequality or logical expressions as a system.

    Parameters:
        conditions (list of str): Each condition is a string (e.g., "x > 2", "y < 5")
        variables (dict): Variable bindings (e.g., {"x": 3, "y": 4})

    Returns:
        bool | None: True if all conditions hold, False if any fail, None if invalid
    """
    try:
        for cond in conditions:
            if not eval(cond, {"__builtins__": None}, variables):
                return False
        return True
    except Exception:
        return None
