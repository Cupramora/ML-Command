# rate_predictor.py

import numpy as np
from scipy.stats import linregress

def predict_rate(x_data: list[float], y_data: list[float], future_x: float) -> float | None:
    """
    Predicts the future value of y at future_x using linear regression.

    Parameters:
        x_data (list): Time or input values
        y_data (list): Observed values
        future_x (float): Future x value to predict y

    Returns:
        float: Predicted y value at future_x
    """
    try:
        slope, intercept, _, _, _ = linregress(x_data, y_data)
        return slope * future_x + intercept
    except Exception:
        return None

def estimate_rate_of_change(x_data: list[float], y_data: list[float]) -> float | None:
    """
    Estimates the average rate of change (slope) over the data.
    """
    try:
        slope, *_ = linregress(x_data, y_data)
        return slope
    except Exception:
        return None
