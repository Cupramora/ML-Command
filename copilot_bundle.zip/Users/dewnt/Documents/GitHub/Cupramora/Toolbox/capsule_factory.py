# capsule_factory.py

from perception import PerceptionCapsule
from capsule_registry import CapsuleRegistry

class CapsuleFactory:
    """
    Creates validated PerceptionCapsule objects from raw input.
    """

    def __init__(self):
        self.registry = CapsuleRegistry()

    def create_capsule(self, capsule_type: str, data: dict) -> PerceptionCapsule:
        if not self.registry.validate_capsule(data, capsule_type):
            raise ValueError(f"Invalid capsule for type '{capsule_type}'")

        return PerceptionCapsule(
            stimulus=data["stimulus"],
            emotion_vector=data["emotion_vector"],
            behavior=data["behavior"],
            context=data["context"],
            feedback=data["feedback"],
            reinforcement=data["reinforcement"]
        )
