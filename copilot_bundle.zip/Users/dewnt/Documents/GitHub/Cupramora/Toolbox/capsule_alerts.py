# capsule_alerts.py

class CapsuleAlerts:
    """
    Flags unexpected behavior transitions based on sequence model predictions.
    """

    def __init__(self, sequence_model):
        self.model = sequence_model

    def check_for_anomaly(self, current_behavior: str, next_behavior: str, threshold: float = 0.1):
        """
        Returns True if the next behavior is unexpected based on transition frequency.
        """
        predictions = self.model.predict_next(current_behavior)
        total = sum(freq for _, freq in predictions)

        if not total:
            return False  # No data yet

        for behavior, freq in predictions:
            if behavior == next_behavior:
                confidence = freq / total
                return confidence < threshold

        return True  # Not seen before at all
