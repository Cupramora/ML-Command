# voice_logger.py

import time

class VoiceLogger:
    """
    Logs all spoken output with timestamps and optional tags.
    """

    def __init__(self):
        self.log = []

    def record(self, text: str, context: str = ""):
        entry = {
            "timestamp": time.strftime("%Y%m%d-%H%M%S"),
            "text": text,
            "context": context
        }
        self.log.append(entry)
        print(f"[LOG] {entry['timestamp']} | {context}: {text}")

    def recent(self, limit: int = 5):
        return self.log[-limit:]

    def export(self) -> list:
        return self.log
