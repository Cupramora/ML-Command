from math_visualizer import MathVisualizer
from math_animator import MathAnimator
from math_tutor import MathTutor
from tutor_memory import TutorMemory
from whiteboard_interface import WhiteboardInterface
from whiteboard_memory import WhiteboardMemory
from speak import Speak

class TutorInterface:
    def __init__(self):
        self.tutor = MathTutor()
        self.memory = TutorMemory()
        self.whiteboard_memory = WhiteboardMemory()
        self.visualizer = MathVisualizer()
        self.animator = None
        self.voice = Speak()
        self.voice.say("Tutor initialized and ready to teach.")

    def open_whiteboard(self, topic: str):
        print("Launching whiteboard...")
        board = WhiteboardInterface()
        board.run()

        try:
            saved = self.whiteboard_memory.save_sketch(
                image_path="whiteboard_capture.png",
                topic=topic,
                notes="Auto-saved after tutoring session"
            )
            print(f"Whiteboard saved: {saved['path']}")
        except Exception as e:
            print(f"Failed to save whiteboard: {e}")

    def explain(self, topic: str, expr: str, clarity_score: float, feedback: str = ""):
        strategy = self.tutor.assess_feedback(clarity_score)
        self.memory.log_session(topic, strategy, clarity_score, feedback)

        print(f"\nTopic: {topic}")
        print(f"Strategy Level: {strategy}")

        if strategy == 1:
            explanation = f"Let's break down '{expr}' step by step."
            print(f"Explanation: {explanation}")
            self.voice.say(explanation)

        elif strategy == 2:
            print(f"Visualizing: {expr}")
            self.voice.say(f"Let's visualize the expression {expr}.")
            self.visualizer.plot_function(expr, label=expr)
            self.visualizer.show(f"Visual of {expr}")

        elif strategy == 3:
            self.voice.say(f"Imagine the curve of {expr} like a rollercoaster.")
            print("Animating the curve...")
            self.animator = MathAnimator(expr)
            self.animator.animate_growth()
            print("Opening whiteboard for visual walkthrough...")
            self.open_whiteboard(topic)

        else:
            print("Default explanation mode.")
            self.voice.say("Using fallback explanation strategy.")

    def review_topic(self, topic: str):
        summary = self.memory.summarize_topic(topic)
        if summary:
            print(f"\nReview of '{topic}':")
            print(f"  - Sessions: {summary['sessions']}")
            print(f"  - Avg Clarity: {summary['avg_clarity']}")
            print(f"  - Most Used Strategy: {summary['most_used_strategy']}")
        else:
            print(f"No prior sessions found for '{topic}'.")