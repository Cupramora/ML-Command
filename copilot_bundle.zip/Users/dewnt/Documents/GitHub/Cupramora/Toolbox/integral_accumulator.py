# integral_accumulator.py

from sympy import symbols, integrate, sympify
from scipy.integrate import quad
import numpy as np

x = symbols('x')

def symbolic_integral(expr_str: str, lower: float = None, upper: float = None) -> str | float | None:
    """
    Computes the symbolic integral of an expression.
    If bounds are provided, returns definite integral.
    """
    try:
        expr = sympify(expr_str)
        if lower is not None and upper is not None:
            return float(integrate(expr, (x, lower, upper)))
        return str(integrate(expr, x))
    except Exception:
        return None

def numerical_integral(func_str: str, lower: float, upper: float) -> float | None:
    """
    Numerically integrates a function string over [lower, upper].
    """
    try:
        f = lambda x_val: eval(func_str, {"x": x_val, "np": np, "__builtins__": {}})
        result, _ = quad(f, lower, upper)
        return result
    except Exception:
        return None
