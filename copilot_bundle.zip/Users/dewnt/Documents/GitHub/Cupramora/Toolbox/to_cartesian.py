# to_cartesian.py
# Convert (r, theta) back to (x, y)

import math

def to_cartesian(r: float, theta: float) -> tuple:
    """
    Converts polar coordinates (r, theta in degrees) to Cartesian (x, y).

    Returns:
        tuple: (x, y)
    """
    theta_rad = math.radians(theta)
    x = r * math.cos(theta_rad)
    y = r * math.sin(theta_rad)
    return (x, y)