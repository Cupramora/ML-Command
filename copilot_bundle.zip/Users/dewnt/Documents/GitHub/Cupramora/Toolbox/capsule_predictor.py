# capsule_predictor.py

from collections import defaultdict, Counter
import time

class CapsulePredictor:
    """
    Predicts likely next behaviors or stimuli based on capsule history.
    """

    def __init__(self, short_term_memory):
        self.memory = short_term_memory

    def predict_next_behavior(self, top_k=3):
        """
        Predicts the most likely next behavior based on recent capsule patterns.
        """
        behaviors = [e["capsule"].behavior for e in self.memory.slots]
        return Counter(behaviors).most_common(top_k)

    def predict_emotion_shift(self):
        """
        Predicts the dominant emotional trend based on recent capsules.
        """
        emotion_totals = defaultdict(float)
        for e in self.memory.slots:
            for emo, val in e["capsule"].emotion_vector.items():
                emotion_totals[emo] += val

        if not emotion_totals:
            return None

        sorted_emotions = sorted(emotion_totals.items(), key=lambda x: x[1], reverse=True)
        return sorted_emotions[0]

    def predict_stimulus_type(self):
        """
        Predicts the most common stimulus channel (e.g. 'audio', 'visual').
        """
        channels = []
        for e in self.memory.slots:
            stim = e["capsule"].stimulus
            if "channel" in stim:
                channels.append(stim["channel"])

        return Counter(channels).most_common(1)[0] if channels else None
