# graph_polynomial.py

import numpy as np
import matplotlib.pyplot as plt

def graph_polynomial(coeffs: list[float], x_range=(-10, 10), steps=400):
    """
    Plots a polynomial given its coefficients.
    coeffs: list of coefficients from highest to lowest degree.
    Example: [1, -3, 2] → x² - 3x + 2
    """
    x = np.linspace(x_range[0], x_range[1], steps)
    y = np.polyval(coeffs, x)

    plt.plot(x, y, label=f"y = {coeffs}")
    plt.axhline(0, color='gray', lw=0.5)
    plt.axvline(0, color='gray', lw=0.5)
    plt.title("Polynomial Graph")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.grid(True)
    plt.legend()
    plt.show()
