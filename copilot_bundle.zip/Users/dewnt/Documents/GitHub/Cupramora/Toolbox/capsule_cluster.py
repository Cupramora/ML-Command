# capsule_cluster.py

from sklearn.cluster import KMeans
import numpy as np

class CapsuleCluster:
    """
    Clusters encoded capsules into experience groups.
    """

    def __init__(self, n_clusters=3):
        self.model = KMeans(n_clusters=n_clusters)
        self.fitted = False

    def fit(self, encoded_vectors):
        self.model.fit(encoded_vectors)
        self.fitted = True

    def predict_cluster(self, encoded_vector):
        if not self.fitted:
            raise RuntimeError("Cluster model not fitted yet.")
        return self.model.predict([encoded_vector])[0]

    def get_centroids(self):
        return self.model.cluster_centers_ if self.fitted else None
