# perception_bridge.py

from short_term import ShortTermMemory
from long_term import LongTermMemory

class PerceptionBridge:
    """
    Receives input capsules, routes them through short-term memory,
    and optionally promotes to long-term memory.
    """

    def __init__(self, st_slots=12):
        self.short_term = ShortTermMemory(max_slots=st_slots)
        self.long_term = LongTermMemory()

    def process_capsule(self, capsule):
        """
        Ingests a perception capsule, logs it to short-term memory,
        and checks for long-term promotion eligibility.
        """
        self.short_term.add_capsule(capsule)
        promotables = self.short_term.get_promotable()

        for cap in promotables:
            if self.long_term._is_promotable(cap):
                self.long_term.store_capsule(cap)

    def recall_recent(self):
        return self.short_term.get_recent()

    def recall_long_term(self, tag=None, min_sig=0.6):
        if tag:
            return self.long_term.recall_by_tag(tag)
        return self.long_term.get_retained(min_sig)
