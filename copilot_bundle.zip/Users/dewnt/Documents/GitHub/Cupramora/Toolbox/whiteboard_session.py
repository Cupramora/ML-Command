# whiteboard_session.py

import time
from whiteboard_memory import WhiteboardMemory
from sketch_analyzer import SketchAnalyzer

class WhiteboardSession:
    """
    Tracks whiteboard usage sessions.
    Links sketches to topics, timestamps, and detected shapes.
    """

    def __init__(self):
        self.memory = WhiteboardMemory()
        self.sessions = []

    def start_session(self, topic: str):
        """
        Begins a new whiteboard session.
        """
        self.current_topic = topic
        self.start_time = time.time()
        print(f"🟢 Whiteboard session started for topic: '{topic}'")

    def end_session(self, image_path: str, notes: str = "") -> dict:
        """
        Ends the session, saves the sketch, and analyzes it.
        """
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        saved = self.memory.save_sketch(image_path, self.current_topic, notes)

        # Analyze sketch
        try:
            analyzer = SketchAnalyzer(image_path)
            shapes = analyzer.detect_shapes()
        except Exception as e:
            shapes = []
            print(f"⚠️ Sketch analysis failed: {e}")

        session = {
            "topic": self.current_topic,
            "timestamp": timestamp,
            "duration_sec": round(time.time() - self.start_time, 2),
            "sketch_path": saved["path"],
            "shapes_detected": shapes,
            "notes": notes
        }

        self.sessions.append(session)
        print(f"🛑 Session ended. Shapes detected: {shapes}")
        return session

    def get_recent_sessions(self, limit: int = 5) -> list:
        return self.sessions[-limit:]
