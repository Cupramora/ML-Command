# math_interface.py

from sympy import sympify
from math_visualizer import MathVisualizer
from math_animator import MathAnimator

class MathInterface:
    """
    Parses natural language math commands and routes to visualizer or animator.
    """

    def __init__(self):
        self.visualizer = MathVisualizer()
        self.animator = None

    def interpret(self, command: str):
        """
        Parses a simple math command and executes it.
        """
        try:
            if "plot" in command:
                expr = self._extract_expression(command)
                self.visualizer.plot_function(expr)
                self.visualizer.show(f"Plot of {expr}")

            elif "shade" in command:
                expr = self._extract_expression(command)
                a, b = self._extract_bounds(command)
                self.visualizer.plot_function(expr)
                self.visualizer.shade_area(expr, a, b)
                self.visualizer.show(f"Area under {expr} from {a} to {b}")

            elif "animate" in command:
                expr = self._extract_expression(command)
                self.animator = MathAnimator(expr)
                self.animator.animate_growth()

            else:
                print("Sorry, I didn't understand that math command.")
        except Exception as e:
            print("Error:", e)

    def _extract_expression(self, text: str) -> str:
        # Naive extraction: assumes expression is after "of" or "animate"
        for key in ["of", "animate", "plot", "shade"]:
            if key in text:
                return text.split(key)[-1].strip()
        return text.strip()

    def _extract_bounds(self, text: str) -> tuple:
        # Naive extraction: looks for "from A to B"
        if "from" in text and "to" in text:
            parts = text.split("from")[-1].split("to")
            return float(parts[0]), float(parts[1])
        return -1, 1
