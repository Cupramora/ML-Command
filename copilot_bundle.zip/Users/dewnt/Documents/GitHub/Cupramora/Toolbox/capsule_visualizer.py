# capsule_visualizer.py

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import time

class CapsuleVisualizer:
    """
    Visualizes short-term memory capsule significance and decay over time.
    """

    def __init__(self, short_term_memory):
        self.memory = short_term_memory

    def plot_significance(self):
        entries = self.memory.slots
        if not entries:
            print("No capsules to visualize.")
            return

        timestamps = [datetime.fromtimestamp(e["timestamp"]) for e in entries]
        raw_scores = [e["significance"] for e in entries]
        decayed_scores = [self.memory._decay_significance(e) for e in entries]
        labels = [e["capsule"].behavior for e in entries]

        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(timestamps, raw_scores, label="Initial Significance", marker="o")
        ax.plot(timestamps, decayed_scores, label="Decayed Significance", marker="x")

        for i, label in enumerate(labels):
            ax.annotate(label, (timestamps[i], decayed_scores[i]), fontsize=8, alpha=0.7)

        ax.set_title("Short-Term Capsule Significance Over Time")
        ax.set_xlabel("Timestamp")
        ax.set_ylabel("Significance Score")
        ax.legend()
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()
