# spatial_analyzer.py

from distance_2d import distance_2d
from angle_between_points import angle_between_points
from to_polar import to_polar
from linear_organizer import LinearOrganizer

class SpatialAnalyzer:
    """
    Uses math tools to interpret spatial relationships from visual input.
    Modular and expandable based on her available toolbox.
    """

    def __init__(self):
        self.organizer = LinearOrganizer(target_cols=3)

    def analyze_frame(self, points: list[tuple]) -> dict:
        """
        Processes keypoints in a 2D frame. Each point is (x, y).
        Applies basic math reasoning: distances, angles, layout.
        """
        result = {}
        n = len(points)

        if n >= 2:
            dists = [
                distance_2d(points[i], points[j])
                for i in range(n) for j in range(i+1, n)
            ]
            result["pairwise_distances"] = dists

        if n >= 3:
            angles = [
                angle_between_points(points[i], points[j], points[k])
                for i in range(n) for j in range(n) for k in range(n)
                if i != j and j != k and i != k
            ]
            result["triple_angles"] = angles

        polar_coords = [to_polar(x, y) for (x, y) in points]
        result["polar_form"] = polar_coords

        grid = self.organizer.organize([coord for pt in points for coord in pt])
        result["matrix_layout"] = grid

        return result
