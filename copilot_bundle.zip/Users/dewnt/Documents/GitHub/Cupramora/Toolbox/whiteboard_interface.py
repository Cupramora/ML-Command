# whiteboard_interface.py

import tkinter as tk
from tkinter.colorchooser import askcolor
from PIL import ImageGrab

class WhiteboardInterface:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("AI Whiteboard")
        self.color = "black"
        self.brush_size = 3
        self.last_x, self.last_y = None, None

        self.canvas = tk.Canvas(self.root, bg="white", width=800, height=600)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self._setup_ui()
        self._bind_events()

    def _setup_ui(self):
        toolbar = tk.Frame(self.root)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        tk.Button(toolbar, text="Color", command=self.choose_color).pack(side=tk.LEFT)
        tk.Button(toolbar, text="Clear", command=self.clear_canvas).pack(side=tk.LEFT)
        tk.Button(toolbar, text="Save", command=self.save_canvas).pack(side=tk.LEFT)

    def _bind_events(self):
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw)

    def choose_color(self):
        color = askcolor()[1]
        if color:
            self.color = color

    def start_draw(self, event):
        self.last_x, self.last_y = event.x, event.y

    def draw(self, event):
        x, y = event.x, event.y
        self.canvas.create_line(self.last_x, self.last_y, x, y,
                                fill=self.color, width=self.brush_size,
                                capstyle=tk.ROUND, smooth=True)
        self.last_x, self.last_y = x, y

    def clear_canvas(self):
        self.canvas.delete("all")

    def save_canvas(self):
        x = self.root.winfo_rootx() + self.canvas.winfo_x()
        y = self.root.winfo_rooty() + self.canvas.winfo_y()
        x1 = x + self.canvas.winfo_width()
        y1 = y + self.canvas.winfo_height()
        ImageGrab.grab().crop((x, y, x1, y1)).save("whiteboard_capture.png")

    def run(self):
        self.root.mainloop()
