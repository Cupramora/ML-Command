# whiteboard_commands.py

from whiteboard_memory import WhiteboardMemory

class WhiteboardCommands:
    """
    Exposes whiteboard memory for search, review, and topic-based recall.
    """

    def __init__(self):
        self.memory = WhiteboardMemory()

    def list_topics(self) -> list:
        return self.memory.list_all_topics()

    def search_by_topic(self, topic: str, limit: int = 5) -> list:
        return self.memory.retrieve_by_topic(topic, limit=limit)

    def describe_sketches(self, topic: str):
        sketches = self.search_by_topic(topic)
        if not sketches:
            print(f"No sketches found for topic '{topic}'.")
            return
        print(f"\n🖼️ Sketches for topic '{topic}':")
        for s in sketches:
            print(f"  - {s['timestamp']}: {s['path']} ({s['notes']})")
