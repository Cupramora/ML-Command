# visual_geometry_probe.py
# This gives her a math eye


from angle_between_points import find_angle
from distance_formula import dist_2d
from to_polar import cart_to_polar

def analyze_frame(frame):
    points = detect_keypoints(frame)  # via OpenCV or custom logic
    if len(points) >= 3:
        a, b, c = points[:3]
        angle = find_angle(a, b, c)
        dist = dist_2d(a, c)
        pol = cart_to_polar(b[0], b[1])
        return {
            "angle_ABC": angle,
            "distance_AC": dist,
            "point_B_polar": pol
        }
