import time
from speak import Speak

class MathTutor:
    """
    Adaptive math tutor using PID-style feedback to adjust teaching strategy.
    Logs sessions for short- and long-term learning.
    """

    def __init__(self, target_clarity=0.9, kp=1.0, ki=0.1, kd=0.05):
        self.target_clarity = target_clarity  # Ideal learner understanding (0–1)
        self.kp = kp
        self.ki = ki
        self.kd = kd

        self.prev_error = 0.0
        self.integral = 0.0
        self.strategy_level = 1  # 1 = basic, 2 = visual, 3 = analogy, etc.
        self.session_log = []

        self.voice = Speak()
        self.voice.say("Math tutor initialized.")

    def assess_feedback(self, clarity_score: float) -> int:
        """
        Adjusts teaching strategy based on learner clarity (0–1).
        Returns new strategy level.
        """
        error = self.target_clarity - clarity_score
        self.integral += error
        derivative = error - self.prev_error
        self.prev_error = error

        adjustment = self.kp * error + self.ki * self.integral + self.kd * derivative

        previous_level = self.strategy_level

        if adjustment > 0.1:
            self.strategy_level = min(self.strategy_level + 1, 3)
        elif adjustment < -0.1:
            self.strategy_level = max(self.strategy_level - 1, 1)

        if previous_level != self.strategy_level:
            self.voice.say(f"Adjusting strategy to level {self.strategy_level}.")

        self._log_session(clarity_score)
        return self.strategy_level

    def _log_session(self, clarity_score: float):
        self.session_log.append({
            "timestamp": time.time(),
            "strategy": self.strategy_level,
            "clarity": clarity_score
        })

    def export_log(self) -> list:
        return self.session_log