# whiteboard_dashboard.py

from whiteboard_commands import WhiteboardCommands
from whiteboard_cleaner import WhiteboardCleaner
from whiteboard_session import WhiteboardSession
from session_reviewer import SessionReviewer
from whiteboard_feedback import WhiteboardFeedback

class WhiteboardDashboard:
    """
    Central hub for managing whiteboard memory, sessions, feedback, and cleanup.
    """

    def __init__(self):
        self.commands = WhiteboardCommands()
        self.cleaner = WhiteboardCleaner()
        self.sessions = WhiteboardSession()
        self.reviewer = SessionReviewer(self.sessions)
        self.feedback = WhiteboardFeedback()

    def show_topics(self):
        topics = self.commands.list_topics()
        print("\n📚 Topics with sketches:")
        for t in topics:
            print(f"  - {t}")

    def review_topic(self, topic: str):
        self.commands.describe_sketches(topic)

    def delete_topic(self, topic: str):
        self.cleaner.clear_topic(topic)

    def start_session(self, topic: str):
        self.sessions.start_session(topic)

    def end_session(self, image_path: str, notes: str = ""):
        return self.sessions.end_session(image_path, notes)

    def submit_feedback(self, sketch_path: str, clarity: float, comment: str = ""):
        self.feedback.submit_feedback(sketch_path, clarity, comment)

    def recent_feedback(self):
        self.feedback.recent_feedback()

    def recent_sessions(self):
        self.reviewer.list_recent_sessions()
