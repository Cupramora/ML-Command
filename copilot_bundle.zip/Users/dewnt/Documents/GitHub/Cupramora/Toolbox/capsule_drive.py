# capsule_drive.py

class CapsuleDrive:
    """
    Determines when to pursue novelty or reinforce known patterns.
    """

    def __init__(self, curiosity_threshold=0.75, similarity_threshold=0.5):
        self.curiosity_threshold = curiosity_threshold
        self.similarity_threshold = similarity_threshold

    def should_explore(self, curiosity_score, similarity_score):
        """
        Returns True if curiosity is high and similarity is low.
        """
        return curiosity_score >= self.curiosity_threshold and similarity_score <= self.similarity_threshold

    def decide_action(self, curiosity_score, similarity_score):
        if self.should_explore(curiosity_score, similarity_score):
            return "explore"
        elif similarity_score > 0.8:
            return "reinforce"
        else:
            return "observe"
