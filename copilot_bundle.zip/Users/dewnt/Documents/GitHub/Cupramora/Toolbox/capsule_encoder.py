# capsule_encoder.py

import numpy as np

class CapsuleEncoder:
    """
    Encodes a capsule into a fixed-length vector for memory compression or similarity.
    """

    def __init__(self):
        self.dim = 6  # Adjustable latent size

    def encode(self, capsule):
        """
        Returns a vector [emotion_mean, novelty, clarity, attention, reinforcement, behavior_hash]
        """
        ev = capsule.emotion_vector
        emotion_mean = np.mean(list(ev.values())) if ev else 0.0
        novelty = capsule.stimulus.get("novelty_score", 0.5)
        clarity = capsule.stimulus.get("clarity", 0.5)
        attention = capsule.stimulus.get("attention", 0.5)
        reinforcement = capsule.reinforcement
        behavior_hash = hash(capsule.behavior) % 1000 / 1000.0

        return np.array([
            round(emotion_mean, 3),
            round(novelty, 3),
            round(clarity, 3),
            round(attention, 3),
            round(reinforcement, 3),
            round(behavior_hash, 3)
        ])
