# capsule_curiosity.py

import time

class CapsuleCuriosity:
    """
    Monitors novelty, emotional spikes, and prediction errors to trigger curiosity.
    """

    def __init__(self):
        self.curiosity_log = []

    def evaluate(self, capsule, prediction=None):
        """
        Returns a curiosity score based on novelty, emotion, and mismatch.
        """
        novelty = capsule.stimulus.get("novelty_score", 0.5)
        emotion_peak = max(capsule.emotion_vector.values())
        mismatch = 0.0

        if prediction and capsule.behavior != prediction:
            mismatch = 1.0

        score = round((novelty * 0.4) + (emotion_peak * 0.4) + (mismatch * 0.2), 3)

        self.curiosity_log.append({
            "timestamp": time.time(),
            "behavior": capsule.behavior,
            "score": score,
            "mismatch": mismatch
        })

        return score

    def recent_spikes(self, threshold=0.75):
        return [e for e in self.curiosity_log if e["score"] >= threshold]
