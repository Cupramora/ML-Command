# scan_memory_mapper.py

import time

class ScanMemoryMapper:
    """
    Stores and retrieves scan results, linking them to timestamps and scan types.
    Enables comparison, recall, and temporal reasoning.
    """

    def __init__(self):
        self.memory = []  # List of dicts: {"type": str, "timestamp": float, "data": dict}

    def store(self, scan_type: str, data: dict):
        """
        Saves a scan result to memory.

        Parameters:
            scan_type (str): Type of scan (e.g., "kinematic", "field")
            data (dict): Result of the scan
        """
        self.memory.append({
            "type": scan_type,
            "timestamp": time.time(),
            "data": data
        })

    def retrieve_recent(self, scan_type: str, limit: int = 5) -> list:
        """
        Retrieves the most recent scan results of a given type.

        Parameters:
            scan_type (str): Type of scan to filter
            limit (int): Max number of entries to return

        Returns:
            list of dicts: Recent scan entries
        """
        filtered = [m for m in self.memory if m["type"] == scan_type]
        return filtered[-limit:]

    def compare_latest(self, scan_type: str) -> dict | None:
        """
        Compares the two most recent scans of a given type.

        Returns:
            dict: Difference summary, or None if not enough data
        """
        recent = self.retrieve_recent(scan_type, limit=2)
        if len(recent) < 2:
            return None

        prev, curr = recent[-2]["data"], recent[-1]["data"]
        diff = {
            k: curr.get(k, 0) - prev.get(k, 0)
            for k in curr if isinstance(curr.get(k), (int, float)) and k in prev
        }
        return diff
