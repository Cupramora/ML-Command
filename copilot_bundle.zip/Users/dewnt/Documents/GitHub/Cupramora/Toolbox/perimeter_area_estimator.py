# perimeter_area_estimator.py
# Approximates shape boundaries from pixel maps
