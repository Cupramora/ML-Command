# math_reasoner.py

class MathReasoner:
    """
    Draws conclusions from stored math capsules.
    Supports rule-based inference, pattern chaining, and contradiction checks.
    """

    def __init__(self, memory):
        """
        Parameters:
            memory: Instance of MathMemory
        """
        self.memory = memory

    def infer_relationships(self) -> list:
        """
        Scans memory for related capsules and infers new relationships.
        Returns a list of inferred statements.
        """
        inferences = []
        recent = self.memory.retrieve_recent(limit=10)

        for i, cap1 in enumerate(recent):
            for cap2 in recent[i+1:]:
                tags1 = set(cap1.get("tags", []))
                tags2 = set(cap2.get("tags", []))
                shared = tags1 & tags2

                if "motion" in shared:
                    v1 = cap1["payload"].get("velocity")
                    v2 = cap2["payload"].get("velocity")
                    if v1 is not None and v2 is not None:
                        if v2 > v1:
                            inferences.append("Object is accelerating.")
                        elif v2 < v1:
                            inferences.append("Object is decelerating.")

                if "directional" in shared:
                    d1 = cap1["payload"].get("direction")
                    d2 = cap2["payload"].get("direction")
                    if d1 is not None and d2 is not None and abs(d1 - d2) > 90:
                        inferences.append("Direction has reversed or turned sharply.")

        return list(set(inferences))

    def detect_conflicts(self) -> list:
        """
        Checks for contradictory capsules (e.g., same tag, opposite values).
        """
        conflicts = []
        recent = self.memory.retrieve_recent(limit=10)

        for cap in recent:
            if "high_magnitude" in cap.get("tags", []) and "motion" in cap.get("tags", []):
                if cap["payload"].get("velocity", 0) < 1:
                    conflicts.append("High magnitude tag with low velocity—possible misclassification.")

        return conflicts
