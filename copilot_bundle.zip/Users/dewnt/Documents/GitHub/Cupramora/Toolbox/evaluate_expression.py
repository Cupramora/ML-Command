# evaluate_expression.py

def evaluate_expression(expr: str, variables: dict = {}) -> float | None:
    """
    Safely evaluates a math expression string with optional variable bindings.

    Parameters:
        expr (str): The expression to evaluate (e.g., "2*x + 3")
        variables (dict): Dictionary of variable values (e.g., {"x": 5})

    Returns:
        float | None: Result of the evaluation, or None if invalid
    """
    try:
        return eval(expr, {"__builtins__": None}, variables)
    except Exception:
        return None
