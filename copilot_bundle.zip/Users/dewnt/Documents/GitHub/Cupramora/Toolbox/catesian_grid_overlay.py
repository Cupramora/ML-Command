# cartesian_grid_overlay.py
# Lay a virtual mesh on image input for spatial reasoning
