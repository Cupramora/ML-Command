# motor_input_listener.py
# receives thrust commands from ML-FlightControl via serial

import json
import serial

class MotorInputListener:
    """
    Listens for incoming thrust commands from ML-FlightControl.
    """

    def __init__(self, port="/dev/ttyUSB0", baudrate=115200):
        self.ser = serial.Serial(port, baudrate, timeout=1)

    def receive(self):
        """
        Reads a line from serial and parses it into a thrust vector.
        """
        line = self.ser.readline().decode("utf-8").strip()
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            return {
                "motor_1": 0.0,
                "motor_2": 0.0,
                "motor_3": 0.0,
                "motor_4": 0.0
            }
