# esc_commander.py
# formats and sends final motor voltages to ESCs via serial or GPIO

import json
import serial  # Replace or extend with GPIO/PWM libraries as needed

class ESCCommander:
    """
    Sends motor voltage commands to ESCs over serial or GPIO.
    """

    def __init__(self, port="/dev/ttyUSB1", baudrate=115200):
        self.ser = serial.Serial(port, baudrate, timeout=1)

    def send(self, voltages):
        """
        Sends a JSON-encoded voltage packet to the ESC controller.
        """
        packet = {
            "motor_1": voltages["motor_1"],
            "motor_2": voltages["motor_2"],
            "motor_3": voltages["motor_3"],
            "motor_4": voltages["motor_4"]
        }
        encoded = json.dumps(packet).encode("utf-8")
        self.ser.write(encoded)
        self.ser.write(b"\n")  # newline as delimiter

    def emergency_shutdown(self):
        """
        Sends a zero-thrust command to all motors.
        """
        zero_packet = json.dumps({
            "motor_1": 0.0,
            "motor_2": 0.0,
            "motor_3": 0.0,
            "motor_4": 0.0
        }).encode("utf-8")
        self.ser.write(zero_packet)
        self.ser.write(b"\n")
