# failsafe_monitor.py
# detects signal loss, invalid thrust, or emergency conditions and triggers shutdown

import time

class FailsafeMonitor:
    """
    Monitors incoming thrust signals for anomalies or loss.
    Triggers emergency shutdown if conditions are unsafe.
    """

    def __init__(self, timeout=0.5, max_voltage=12.5):
        self.last_signal_time = time.time()
        self.timeout = timeout
        self.max_voltage = max_voltage

    def triggered(self, thrust_vector):
        now = time.time()
        if now - self.last_signal_time > self.timeout:
            return True  # signal timeout

        for v in thrust_vector.values():
            if v < 0.0 or v > self.max_voltage:
                return True  # unsafe voltage

        self.last_signal_time = now
        return False
