# voltage_mapper.py
# maps normalized thrust (0.0–1.0) to ESC voltage or PWM values

class VoltageMapper:
    """
    Converts normalized thrust values into real-world voltage or PWM signals.
    """

    def __init__(self, min_voltage=1.0, max_voltage=12.0):
        self.min_v = min_voltage
        self.max_v = max_voltage

    def map(self, thrust_vector):
        """
        Maps each motor's thrust (0.0–1.0) to a voltage value.
        """
        return {
            motor: self._scale(thrust)
            for motor, thrust in thrust_vector.items()
        }

    def _scale(self, thrust):
        thrust = max(0.0, min(1.0, thrust))  # Clamp to [0, 1]
        voltage = self.min_v + thrust * (self.max_v - self.min_v)
        return round(voltage, 3)
