# thrust_logger.py
# records motor voltage outputs to CSV for analysis and training

import csv
import os
import time

class ThrustLogger:
    """
    Logs motor voltage outputs over time for diagnostics and learning.
    """

    def __init__(self, filename="logs/thrust_log.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            os.makedirs(os.path.dirname(self.filename), exist_ok=True)
            with open(self.filename, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "timestamp", "motor_1", "motor_2", "motor_3", "motor_4"
                ])

    def log(self, voltages):
        with open(self.filename, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                round(time.time(), 3),
                voltages["motor_1"],
                voltages["motor_2"],
                voltages["motor_3"],
                voltages["motor_4"]
            ])
