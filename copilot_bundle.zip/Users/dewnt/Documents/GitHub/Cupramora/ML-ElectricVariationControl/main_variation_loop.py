# main_variation_loop.py
# receives thrust vectors and dispatches ESC signals via voltage mapping and thrust balancing

import time
from interface.motor_input_listener import MotorInputListener
from variation_controller.voltage_mapper import VoltageMapper
from variation_controller.thrust_balancer import ThrustBalancer
from variation_controller.esc_commander import ESCCommander
from safety.failsafe_monitor import FailsafeMonitor
from logs.thrust_logger import ThrustLogger

# Initialize modules
listener = MotorInputListener(port="/dev/ttyUSB0", baudrate=115200)
mapper = VoltageMapper(min_voltage=1.0, max_voltage=12.0)
balancer = ThrustBalancer()
commander = ESCCommander()
failsafe = FailsafeMonitor()
logger = ThrustLogger()

frequency = 100  # Hz
dt = 1.0 / frequency

print("⚙️  Electric Variation Control loop engaged.")

while True:
    # 1. Receive motor thrust signals from ML-FlightControl
    thrust_vector = listener.receive()

    # 2. Check failsafe conditions
    if failsafe.triggered(thrust_vector):
        commander.emergency_shutdown()
        print("🛑 Failsafe triggered. Motors shut down.")
        break

    # 3. Map normalized thrust to voltage or PWM
    voltages = mapper.map(thrust_vector)

    # 4. Apply thrust balancing (e.g. yaw correction, sync)
    balanced = balancer.balance(voltages)

    # 5. Send to ESCs
    commander.send(balanced)

    # 6. Log output
    logger.log(balanced)

    time.sleep(dt)
