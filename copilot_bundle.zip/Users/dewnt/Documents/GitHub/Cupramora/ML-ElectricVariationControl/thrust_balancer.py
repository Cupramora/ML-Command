# thrust_balancer.py
# applies cross-motor compensation and synchronization to voltage outputs

class ThrustBalancer:
    """
    Applies balancing logic to motor voltages to ensure smooth, coordinated thrust.
    Includes optional yaw correction, motor sync, and drift compensation.
    """

    def __init__(self, sync=True, max_delta=1.5):
        self.sync = sync
        self.max_delta = max_delta  # max allowed voltage difference between motors (V)

    def balance(self, voltages):
        """
        Adjusts motor voltages to maintain symmetry and prevent overdrive.
        """
        values = list(voltages.values())
        avg = sum(values) / len(values)

        balanced = {}
        for motor, v in voltages.items():
            delta = v - avg
            if abs(delta) > self.max_delta:
                v = avg + self.max_delta * (1 if delta > 0 else -1)
            balanced[motor] = round(v, 3)

        if self.sync:
            # Optional: normalize all to same average if needed
            balanced = {m: avg for m in balanced}

        return balanced
