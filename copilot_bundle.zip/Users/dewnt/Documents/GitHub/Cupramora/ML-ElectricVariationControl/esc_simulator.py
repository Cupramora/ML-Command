# esc_simulator.py
# simulates ESC behavior for testing without hardware

class ESCSimulator:
    """
    Simulates ESC response to voltage commands.
    Useful for testing thrust logic and signal timing.
    """

    def __init__(self):
        self.last_command = {}

    def send(self, voltages):
        self.last_command = voltages
        print(f"[SIM] ESC Voltages → {voltages}")

    def emergency_shutdown(self):
        print("[SIM] Emergency shutdown triggered. All motors set to 0V.")
        self.last_command = {
            "motor_1": 0.0,
            "motor_2": 0.0,
            "motor_3": 0.0,
            "motor_4": 0.0
        }
